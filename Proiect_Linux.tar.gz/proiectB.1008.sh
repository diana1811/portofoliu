#!/bin/bash
#POPA ALEXANDRA-GABRIELA si POPA DIANA-MARIA 1008

i=$1 #alegerea exercitiului prin argument

	functie(){
                   echo "Se cere de la tastatura introducere shell"
                   read n
                   grep "$n" /etc/passwd | wc -l #caut shell-ul si numar liniile in care apare 
	}
	
	
	
	f(){
                echo "Dati de la tastatura numarul de utilizatori pe care doriti sa-i introduceti, apoi numele lor"
                read a #citesc nr de utilizatori
                echo "$a" >> model.txt #redirectez nr de utilizatori la model.txt
                j=0
                while [ $j -lt $a ] #citesc de la tastatura si pun numele in model.txt
                do {
                        ((j++))
                        read b
                        printf "$b\n" >> model.txt
                }
                done
        }
	
	
	
	functie3(){
                        echo "Dati numele fisierului care contine lista cu utilizatorii"
                        read x
                        sed '1d' $x > users #sterg prima linie(nr de utilizatori) si redirectez restul in fisier user
                        for Line in $(cat users) #pentru fiecare linie adaug user si dau mesaj
                        do {
                                useradd "$Line"
                                if  [ $? -eq 0 ]; then
                                        echo "S-a creat $Line"
                                else
                                        echo "Nu s-a creat"
                                fi
                        }
                done
                        if [ "$EUID" -ne 0 ] #verific rulare cu root
                        then echo "Rulati ca root"
                        fi
                }
		
		
	functie4(){
                        echo "Dati numele fisierului care contine lista cu utilizatorii"
                        read x
                        sed '1d' $x > users #sterg prima linie si redirectez la user
                        for Line in $(cat users) #pentru fiecare linie sterg user si dau mesaj
                        do {
                                userdel "$Line"
                                if  [ $? -eq 0 ]; then
                                        echo "S-a sters $Line"
                                else
                                        echo "Nu s-a sters"
                                fi
                        }
                done
                        if [ "$EUID" -ne 0 ] #verific root
                        then echo "Rulati ca root"
                        fi
                }

case $i in
	1) #primul exercitiu
		functie  ;; 
        2) #exercitiul 2
		f   ;;
	3) #exercitiul 3
		functie3 ;;
	4) #xercitiul 4
		functie4 ;;
       	*) #daca nu s-a dat ca argument 1,2,3 sau 4
		echo "Puteti alege o varianta dintre urmatoarele puncte: 1, 2, 3 sau 4" ;;
esac

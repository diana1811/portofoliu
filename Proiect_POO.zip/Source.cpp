#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
#include<fstream>
#include<map>
#include<vector>
#include<set>
#include<list>
using namespace std;

class ExceptieInput {
    string mesaj;
public:
    ExceptieInput(string mesaj) :mesaj(mesaj) {}
    string getMesaj() {
        return this->mesaj;
    }
};
class Ifile
{
public:

    virtual void writeToFile(fstream& f) = 0;
    virtual void restoreFromFile(fstream& f) = 0;
    virtual void writeToTextFile(ofstream& out) = 0;
    virtual void readFromTextFile(ifstream& in) = 0;

};
class Ingredient :public Ifile {
    char* nume = nullptr;
    int cantitateDisp = 0;
public:
    Ingredient() {
        this->nume = nullptr;
        this->cantitateDisp = 0;
    }
    Ingredient(const char* nume, int cantitateDisp) {
        if (nume != nullptr) {
            this->nume = new char[strlen(nume) + 1];
            strcpy(this->nume, nume);
        }
        this->cantitateDisp = cantitateDisp;
    }
    Ingredient(const Ingredient& i) {
        if (i.nume != nullptr) {
            this->nume = new char[strlen(i.nume) + 1];
            strcpy(this->nume, i.nume);
        }
        this->cantitateDisp = i.cantitateDisp;
    }
    Ingredient& operator=(const Ingredient& i) {
        if (this != &i) {
            delete[] this->nume;
            this->nume = nullptr;
            if (i.nume != nullptr) {
                this->nume = new char[strlen(i.nume) + 1];
                strcpy(this->nume, i.nume);
            }
            this->cantitateDisp = i.cantitateDisp;
        }
        return *this;
    }
    void setCantitate(int cantitateDisp) {
        if (cantitateDisp > -1) {
            this->cantitateDisp = cantitateDisp;
        }
        else throw new ExceptieInput("Cantitate invalida");
    }
    const char* getNume() {
        return this->nume;
    }
    int getCantitate() {
        return this->cantitateDisp;
    }
    void setNume(const char* nume) {
        if (strlen(nume) > 0) {
            this->nume = new char[strlen(nume) + 1];
            strcpy(this->nume, nume);
        }
        else throw new ExceptieInput("Nume invalid");
    }
    //scade cantitatea si afiseaza rezultatul de dupa
    Ingredient& operator--() {
        if (this->cantitateDisp > 0) {
            this->cantitateDisp--;
        }
        return *this;
    }
    //scade cantitatea si afiseaza rezultatul dinainte
    Ingredient& operator--(int) {
        Ingredient copie = *this;
        if (this->cantitateDisp > 0) {
            this->cantitateDisp--;
        }
        return copie;
    }

    //returneaza cantitatea doar daca este peste o duzina
    explicit operator int() {
        if (cantitateDisp > 12) {
            return this->cantitateDisp;
        }
    }
    //daca !ingredient inseamna ca nu am cantitate disponibila
    bool operator!() {
        return (this->cantitateDisp != 0);
    }
    //calc care ingredient are disponibilitatea mai mare
    bool operator>(const Ingredient& i) {
        if (this->cantitateDisp > i.cantitateDisp) {
            return true;
        }
        return false;
    }
    //verific daca doua ingrediente sunt identice
    bool operator==(const Ingredient& i) {
        if (this->cantitateDisp == i.cantitateDisp) {
            if (this->nume != nullptr && i.nume != nullptr) {
                if (this->nume == i.nume) {
                    return true;
                }
            }
        }
        return false;
    }

    bool operator!=(const Ingredient& i) {
        if (this->cantitateDisp != i.cantitateDisp) {
            if (this->nume != nullptr && i.nume != nullptr) {
                if (this->nume != i.nume) {
                    return true;
                }
            }
        }
        return false;
    }

    void adaugareStoc(int stocSuplimentar) {
        if (stocSuplimentar > 0) {
            this->cantitateDisp = this->cantitateDisp + stocSuplimentar;
        }
    }

    void scadereStoc(int stocConsumat) {
        if (stocConsumat > 0) {
            this->cantitateDisp = this->cantitateDisp - stocConsumat;
        }
    }

    friend ostream& operator<<(ostream& out, const Ingredient& i) {
        if (i.nume != nullptr) {
            out << "\nNume ingrediente:" << i.nume;
        }
        out << "\nCanitate Disponibila:" << i.cantitateDisp;
        return out;
    }
    friend ofstream& operator<<(ofstream& out, const Ingredient& i) {
        if (i.nume != nullptr) {
            out << i.nume << endl;
        }
        out << i.cantitateDisp << endl;
        return out;
    }
    void afisare() {
        if (this->nume != nullptr) {
            cout << "\nNume ingredient:" << this->nume;
        }
        cout << "\nCanitate Disponibila:" << this->cantitateDisp;
    }
    friend istream& operator>>(istream& in, Ingredient& i) {
        delete[] i.nume;
        i.nume = nullptr;
        string buffer;
        cout << "\nnume ing:";
        in >> buffer;
        i.nume = new char[buffer.length() + 1];
        strcpy(i.nume, buffer.data());
        cout << "\nCantitateDisp:" << endl; in >> i.cantitateDisp;
        return in;
    }
    friend ifstream& operator>>(ifstream& in, Ingredient& i) {
        delete[] i.nume;
        i.nume = nullptr;
        string buffer;
        in >> buffer;
        i.nume = new char[buffer.length() + 1];
        strcpy(i.nume, buffer.data());
        in >> i.cantitateDisp;
        return in;
    }
    void writeToFile(fstream& f) {
        int lg = strlen(this->nume)+1;
        f.write((char*)&lg, sizeof(int));
        f.write(this->nume, lg);
        f.write((char*)&this->cantitateDisp, sizeof(int));
    }
    void restoreFromFile(fstream& f) {
        int lg = 0;

        if (this->nume != nullptr) {
            delete[]this->nume;
        }
        f.read((char*)&lg, sizeof(int));
        char* buffer = new char[lg];
        f.read(buffer, lg);
        this->nume = new char[lg];
        strcpy(this->nume, buffer);

        f.read((char*)&this->cantitateDisp, sizeof(int));
    }
    void writeToTextFile(ofstream& out) {
        if (this->nume != nullptr) {
            out << this->nume << endl;
        }
        out << this->cantitateDisp << endl;

    }
    void readFromTextFile(ifstream& in) {
        delete[] this->nume;
        this->nume = nullptr;
        string buffer;
        in >> buffer;
        this->nume = new char[buffer.length() + 1];
        strcpy(this->nume, buffer.data());
        in >> this->cantitateDisp;

    }
    void exportCSV(int dim, Ingredient* ing) {
        ofstream fCSV("Raport1.csv", ios::out);
        for (int i = 0; i < dim; i++) {
            fCSV << ing[i] << ",";

        }
        fCSV.close();
    }

    ~Ingredient() {
        delete[] this->nume;
        this->nume = nullptr;
    }
};

class Produs :public Ifile {
    string nume = "n/a";
    Ingredient* retetar = nullptr;
    int nrIngrediente = 0;
    int* cantitati = nullptr;

public:
    void setNume(string nume) {
        if (nume.length() > 0) {
            this->nume = nume;
        }
        else throw new ExceptieInput("Nume invalid");
    }
    const string getNume() {
        return this->nume;
    }
    const int getNrIngrediente() {
        return this->nrIngrediente;
    }
    void setCantitati(int nrIngrediente, int* cantitati) {
        if (cantitati != nullptr && nrIngrediente > 0) {
            delete this->cantitati;
            this->cantitati = nullptr;
            this->cantitati = new int[nrIngrediente];
            this->nrIngrediente = nrIngrediente;
            for (int i = 0; i < nrIngrediente; i++) {
                this->cantitati[i] = cantitati[i];
            }
        }
        else throw new ExceptieInput("Cantitati invalide");
    }
    void setRetetar(int nrIngrediente, Ingredient* retetar) {
        if (retetar != nullptr && nrIngrediente > 0) {
            delete this->retetar;
            this->retetar = nullptr;
            this->retetar = new Ingredient[nrIngrediente];
            this->nrIngrediente = nrIngrediente;
            for (int i = 0; i < nrIngrediente; i++) {
                this->retetar[i] = retetar[i];
            }
        }
        else throw new ExceptieInput("Retetar invalid");
    }
    const Ingredient* getRetetar() {
        return this->retetar;
    }
    const int* getCantitati() {
        return this->cantitati;
    }
    Produs() {
        this->nume = "n/a";
        this->retetar = nullptr;
        this->nrIngrediente = 0;
        this->cantitati = nullptr;
    }
    Produs(string nume, Ingredient* retetar, int nrIngrediente, int* cantitati) {
        this->nume = nume;
        if (retetar != nullptr && nrIngrediente > 0) {
            this->nrIngrediente = nrIngrediente;
            this->retetar = new Ingredient[nrIngrediente];
            for (int i = 0; i < nrIngrediente; i++) {
                this->retetar[i] = retetar[i];
            }
        }
        if (cantitati != nullptr && this->nrIngrediente > 0) {
            this->cantitati = new int[nrIngrediente];
            for (int i = 0; i < nrIngrediente; i++) {
                this->cantitati[i] = cantitati[i];
            }
        }
    }
    Produs(const Produs& p) {
        this->nume = p.nume;
        if (p.retetar != nullptr && p.nrIngrediente > 0) {
            this->nrIngrediente = p.nrIngrediente;
            this->retetar = new Ingredient[p.nrIngrediente];
            for (int i = 0; i < p.nrIngrediente; i++) {
                this->retetar[i] = p.retetar[i];
            }
        }
        if (p.cantitati != nullptr && this->nrIngrediente > 0) {
            this->cantitati = new int[p.nrIngrediente];
            for (int i = 0; i < p.nrIngrediente; i++) {
                this->cantitati[i] = p.cantitati[i];
            }
        }
    }
    Produs& operator=(const Produs& p) {
        if (this != &p) {
            delete[] this->retetar;
            this->retetar = nullptr;
            delete[] this->cantitati;
            this->cantitati = nullptr;
            this->nume = p.nume;
            if (p.retetar != nullptr && p.nrIngrediente > 0) {
                this->nrIngrediente = p.nrIngrediente;
                this->retetar = new Ingredient[p.nrIngrediente];
                for (int i = 0; i < p.nrIngrediente; i++) {
                    this->retetar[i] = p.retetar[i];
                }
            }
            if (p.cantitati != nullptr && this->nrIngrediente > 0) {
                this->cantitati = new int[p.nrIngrediente];
                for (int i = 0; i < p.nrIngrediente; i++) {
                    this->cantitati[i] = p.cantitati[i];
                }
            }
        }
        return *this;
    }
    void adaugaIngredient(int cantitate, const Ingredient& ingredient) {
        Ingredient* copie;
        int* copie_c;
        copie_c = new int[this->nrIngrediente + 1];
        copie = new Ingredient[this->nrIngrediente + 1];
        for (int i = 0; i < this->nrIngrediente; i++) {
            copie[i] = this->retetar[i];
            copie_c[i] = this->cantitati[i];
        }
        copie[this->nrIngrediente] = ingredient;
        copie_c[this->nrIngrediente] = cantitate;
        this->nrIngrediente++;
        delete[] this->retetar;
        this->retetar = nullptr;
        this->retetar = copie;
        delete[] this->cantitati;
        this->cantitati = nullptr;
        this->cantitati = copie_c;
    }
    bool verificaDisp() {
        for (int j = 0; j < this->nrIngrediente; j++) {

            if (this->cantitati[j] > retetar[j].getCantitate()) {
                return false;
            }

        }
        return true;
    }

    int operator[](int pozitie) {
        if (pozitie >= 0 && pozitie < this->nrIngrediente) {
            if (this->cantitati != nullptr) {
                return this->cantitati[pozitie];
            }
        }
    }

    int* operator-(Ingredient*& ingredient) {
        int* cantitati = new int[this->nrIngrediente];

        for (int i = 0; i < this->nrIngrediente; i++) {
            int cantitateNoua = ingredient[i].getCantitate() - this->cantitati[i];
            ingredient[i].setCantitate(cantitateNoua);
            cantitati[i] = cantitateNoua;
        }

        return cantitati;
    }

    bool operator==(const Produs& p) {
        if (this->nume != p.nume ||
            this->nrIngrediente != p.nrIngrediente)
        {
            return false;
        }
        if (this->nrIngrediente > 0 && this->retetar != nullptr && p.nrIngrediente > 0 && p.retetar != nullptr) {
            for (int i = 0; i < this->nrIngrediente; i++) {
                if (this->retetar[i] != p.retetar[i]) {
                    return false;
                }
            }
            if (this->cantitati != nullptr && p.cantitati != nullptr) {
                for (int i = 0; i < this->nrIngrediente; i++) {
                    if (this->cantitati[i] != p.cantitati[i]) {
                        return false;
                    }
                }
            }
        }

        return true;
    }


    friend ostream& operator<<(ostream& out, Produs& p) {
        out << "\n----------------------------";
        out << "\nNume Produs :" << p.nume << endl;
        if (p.retetar != nullptr && p.nrIngrediente > 0) {
            out << "\nNr. Ingrediente:" << p.nrIngrediente;
            out << "\nRetetar:";
            for (int i = 0; i < p.nrIngrediente; i++) {
                out << p.retetar[i];
            }
        }
        else {
            out << "\nNr. Ingrediente:-";
            out << "\nRetetar:-";
        }
        out << "\nCantitati:";
        if (p.cantitati != nullptr && p.nrIngrediente > 0) {
            for (int i = 0; i < p.nrIngrediente; i++) {
                out << p.cantitati[i];
            }
        }
        else {
            out << "-";
        }
        out << "\n----------------------------";
        return out;
    }

    friend ofstream& operator<<(ofstream& out, Produs& p) {
        out << "\n----------------------------";
        out << p.nume << endl;
        if (p.retetar != nullptr && p.nrIngrediente > 0) {
            out << p.nrIngrediente;

            for (int i = 0; i < p.nrIngrediente; i++) {
                out << p.retetar[i];
            }
        }
        else {
            out << "\nNr. Ingrediente:-";
            out << "\nRetetar:-";
        }

        if (p.cantitati != nullptr && p.nrIngrediente > 0) {
            for (int i = 0; i < p.nrIngrediente; i++) {
                out << p.cantitati[i];
            }
        }
        else {
            out << "-";
        }
        out << "\n----------------------------";
        return out;
    }

    void afisare() {
        cout << "\n----------------------------";
        cout << "\nnume :" << this->nume << endl;
        if (this->retetar != nullptr && this->nrIngrediente > 0) {
            cout << "\nNrIngrediente:" << this->nrIngrediente;
            for (int i = 0; i < this->nrIngrediente; i++) {
                cout << "\nRetetar:" << this->retetar[i];
            }
        }

        if (this->cantitati != nullptr && this->nrIngrediente > 0) {
            for (int i = 0; i < this->nrIngrediente; i++) {
                cout << "\nCantitati:" << this->cantitati[i];
            }
        }

        cout << "\n----------------------------";
    }

    friend istream& operator>>(istream& in, Produs& p) {
        delete[] p.retetar;
        p.retetar = nullptr;
        delete[] p.cantitati;
        p.cantitati = nullptr;
        cout << "\nnumeprodus :";
        in >> p.nume;
        cout << "nrIngrediente:";
        in >> p.nrIngrediente;
        if (p.nrIngrediente < 0) {
            p.nrIngrediente = 0;
            p.retetar = nullptr;
            p.cantitati = nullptr;
        }
        else {
            p.retetar = new Ingredient[p.nrIngrediente];
            for (int i = 0; i < p.nrIngrediente; i++) {
                cout << "\nretetar:";  in >> p.retetar[i];
            }
            p.cantitati = new int[p.nrIngrediente];
            for (int i = 0; i < p.nrIngrediente; i++) {
                cout << "\ncantitati:";
                in >> p.cantitati[i];
            }
        }
        return in;
    }

    friend ifstream& operator>>(ifstream& in, Produs& p) {
        delete[] p.retetar;
        p.retetar = nullptr;
        delete[] p.cantitati;
        p.cantitati = nullptr;
        cout << "\nnumeprodus :";
        in >> p.nume;
        cout << "nrIngrediente:";
        in >> p.nrIngrediente;
        if (p.nrIngrediente < 0) {
            p.nrIngrediente = 0;
            p.retetar = nullptr;
            p.cantitati = nullptr;
        }
        else {
            p.retetar = new Ingredient[p.nrIngrediente];
            for (int i = 0; i < p.nrIngrediente; i++) {
                cout << "\nretetar:";  in >> p.retetar[i];
            }
            p.cantitati = new int[p.nrIngrediente];
            for (int i = 0; i < p.nrIngrediente; i++) {
                cout << "\ncantitati:";
                in >> p.cantitati[i];
            }
        }
        return in;
    }
    void writeToFile(fstream& f1) {
        int lg = this->nume.size();
        f1.write((char*)&lg, sizeof(int));
        f1.write(this->nume.c_str(), lg + 1);
        f1.write((char*)&this->nrIngrediente, sizeof(this->nrIngrediente));
        for (int i = 0; i < this->nrIngrediente; i++) {
            f1.write((char*)&this->cantitati[i], sizeof(this->cantitati[i]));

        }

        for (int i = 0; i < this->nrIngrediente; i++) {
            // f1.write((char*)&this->retetar[i], sizeof(this->retetar[i]));
            this->retetar[i].writeToFile(f1);
        }




    }
    void restoreFromFile(fstream& f1) {
        int lg = 0;
        f1.read((char*)&lg, sizeof(lg));
        char* buffer = new char[lg + 1];
        f1.read(buffer, lg + 1);
        this->nume = buffer;

        f1.read((char*)&this->nrIngrediente, sizeof(int));
        if (this->nrIngrediente > 0) {
            this->cantitati = new int[this->nrIngrediente];
            this->retetar = new Ingredient[this->nrIngrediente];
            for (int i = 0; i < this->nrIngrediente; i++) {
                f1.read((char*)&this->cantitati[i], sizeof(this->cantitati[i]));
            }
            for (int i = 0; i < this->nrIngrediente; i++) {
                // f1.read((char*)&this->retetar[i], sizeof(this->retetar[i]));
                this->retetar[i].restoreFromFile(f1);
            }

        }
        else {
            this->retetar = nullptr;
            this->cantitati = nullptr;
            this->nrIngrediente = 0;
        }
    }
    void writeToTextFile(ofstream& out) {
        out << this->nume << endl;
        if (this->retetar != nullptr && this->nrIngrediente > 0) {
            out << this->nrIngrediente;

            for (int i = 0; i < this->nrIngrediente; i++) {
                out << this->retetar[i];
            }
        }
        else {
            out << "\nNr. Ingrediente:-";
            out << "\nRetetar:-";
        }

        if (this->cantitati != nullptr && this->nrIngrediente > 0) {
            for (int i = 0; i < this->nrIngrediente; i++) {
                out << this->cantitati[i] << endl;
            }
        }
        else {
            out << "-";
        }
    }
    void readFromTextFile(ifstream& in) {
        delete[] this->retetar;
        this->retetar = nullptr;
        delete[] this->cantitati;
        this->cantitati = nullptr;
        in >> this->nume;
        in >> this->nrIngrediente;
        if (this->nrIngrediente < 0) {
            this->nrIngrediente = 0;
            this->retetar = nullptr;
            this->cantitati = nullptr;
        }
        else {
            this->retetar = new Ingredient[this->nrIngrediente];
            for (int i = 0; i < this->nrIngrediente; i++) {
                in >> this->retetar[i];
            }
            this->cantitati = new int[this->nrIngrediente];
            for (int i = 0; i < this->nrIngrediente; i++) {
                in >> this->cantitati[i];
            }
        }

    }

    void exportCSV(int dim, Produs* p) {
        ofstream fCSV("Raport1.csv", ios::out);
        for (int i = 0; i < dim; i++) {
            fCSV << p[i] << ",";
            fCSV.close();
        }
    }

    ~Produs() {
        delete[] this->retetar;
        this->retetar = nullptr;
        delete[] this->cantitati;
        this->cantitati = nullptr;
    }
};


class Angajat :public Ifile {
    string nume = "n/a";
    string functie = "n/a";
    int vechime = 0;
    int nrZileConcediu = 0;
public:
    Angajat() {
        this->nume = "n/a";
        this->functie = "n/a";
        this->vechime = 0;
        this->nrZileConcediu = 0;
    }
    Angajat(string nume, string functie, int vechime, int nrZileConcediu) {
        if (nume.size() >= 3) {
            this->nume = nume;
        }
        this->functie = functie;
        if (vechime > 0) {
            this->vechime = vechime;
        }
        this->nrZileConcediu = nrZileConcediu;

    }
    Angajat(const Angajat& a) {
        if (a.nume.size() > 3) {
            this->nume = a.nume;
        }
        this->functie = a.functie;
        if (a.vechime > 0) {
            this->vechime = a.vechime;
        }
        this->nrZileConcediu = a.nrZileConcediu;
    }
    Angajat& operator=(Angajat& a) {
        if (this != &a) {
            if (a.nume.size() > 3) {
                this->nume = a.nume;
            }
            this->functie = a.functie;
            if (a.vechime > 0) {
                this->vechime = a.vechime;
            }
            this->nrZileConcediu = a.nrZileConcediu;
        }
        return *this;
    }
    friend ostream& operator<<(ostream& out, Angajat& a) {
        out << "\n--------------";
        out << "\nNumele:" << a.nume;
        out << "\nFunctie:" << a.functie;
        out << "\nVechimea:" << a.vechime;
        out << "\nZile concediu:" << a.nrZileConcediu;
        return out;
    }
    friend istream& operator>>(istream& in, Angajat& a) {
        cout << "\nIntroduceti numele:";
        in >> a.nume;
        cout << "\nIntroduceti functia:";
        in >> a.functie;
        cout << "\nIntroduceti vechimea:";
        in >> a.vechime;
        cout << "\nIntroduceti zilele de concediu:";
        in >> a.nrZileConcediu;
        return in;
    }
    void writeToFile(fstream& f4) {
        int lg = this->nume.length() + 1;
        f4.write((char*)&lg, sizeof(int));
        f4.write(nume.data(), lg);
        int lg1 = this->functie.length() + 1;
        f4.write((char*)&lg1, sizeof(int));
        f4.write(functie.data(), lg1);
        f4.write((char*)&this->vechime, sizeof(int));
        f4.write((char*)&this->nrZileConcediu, sizeof(int));
    }
    void restoreFromFile(fstream& f4) {
        int lg = 0;
        f4.read((char*)&lg, sizeof(int));
        char* buffer = new char[lg];
        f4.read(buffer, lg);
        this->nume = buffer;
        delete[]buffer;
        f4.read((char*)&lg, sizeof(int));
        buffer = new char[lg];
        f4.read(buffer, lg);
        this->functie = buffer;
        delete[]buffer;
        f4.read((char*)&this->vechime, sizeof(int));
        f4.read((char*)&this->nrZileConcediu, sizeof(int));
    }
    void writeToTextFile(ofstream& out) {
        out << "--------------";
        out << "\nNumele:" << this->nume;
        out << "\nFunctie:" << this->functie;
        out << "\nVechimea:" << this->vechime;
        out << "\nZile concediu:" << this->nrZileConcediu;
    }
    void readFromTextFile(ifstream& in) {

        in >> this->nume;

        in >> this->functie;

        in >> this->vechime;

        in >> this->nrZileConcediu;
    }
    virtual int zileConcediu() {
        return this->nrZileConcediu;
    }
    virtual void demisia() {
        cout << endl << this->nume << " " << "si-a dat demisia." << endl;
    }
    ~Angajat() {}
};

class Ospatar :public Angajat {
    int nrMese = 0;
    int nrComenzi = 0;
public:
    Ospatar() {
        this->nrMese = 0;
        this->nrComenzi = 0;
    }
    Ospatar(string nume, string functie, int vechime, int nrZileConcediu, int nrMese, int nrComenzi) :Angajat(nume, functie, vechime, nrZileConcediu) {
        this->nrMese = nrMese;
        this->nrComenzi = nrComenzi;
    }
    Ospatar(const Ospatar& o) :Angajat(o) {
        this->nrMese = o.nrMese;
        this->nrComenzi = o.nrComenzi;
    }
    Ospatar& operator=(Ospatar& o) {
        if (this != &o) {
            this->Angajat::operator=(o);
            this->nrMese = o.nrMese;
            this->nrComenzi = o.nrComenzi;
        }
        return *this;
    }
    friend ostream& operator<<(ostream& out, Ospatar& o) {
        out << (Angajat&)o;
        out << "\nNr Mese: " << o.nrMese;
        out << "\nNr comenzi: " << o.nrComenzi;
        return out;
    }
    friend istream& operator>>(istream& in, Ospatar& o) {
        in >> (Angajat&)o;
        in >> o.nrMese;
        in >> o.nrComenzi;
        return in;
    }
    int zileConcediu() {
        return Angajat::zileConcediu() + 5;
    }
    void demisia() {
        cout << endl << "ospatarul si-a dat demisia din cauza salariului.";
    }
    ~Ospatar() {}
};

class PersonalRestaurant {
    int nrOspatari = 0;
    Ospatar* ospatari = nullptr;
public:
    PersonalRestaurant() {
        this->nrOspatari = 0;
        this->ospatari = nullptr;
    }
    PersonalRestaurant(int nrOspatari, Ospatar* ospatari) {
        if (nrOspatari > 0 && ospatari != nullptr) {
            this->nrOspatari = nrOspatari;
            this->ospatari = new Ospatar[this->nrOspatari];
            for (int i = 0; i < this->nrOspatari; i++) {
                this->ospatari[i] = ospatari[i];
            }
        }
    }
    PersonalRestaurant(const PersonalRestaurant& p) {
        if (p.nrOspatari > 0 && p.ospatari != nullptr) {
            this->nrOspatari = p.nrOspatari;
            this->ospatari = new Ospatar[this->nrOspatari];
            for (int i = 0; i < this->nrOspatari; i++) {
                this->ospatari[i] = p.ospatari[i];
            }
        }
    }
    PersonalRestaurant& operator=(PersonalRestaurant& p) {
        if (this != &p) {
            if (p.nrOspatari > 0 && p.ospatari != nullptr) {
                this->nrOspatari = p.nrOspatari;
                this->ospatari = new Ospatar[this->nrOspatari];
                for (int i = 0; i < this->nrOspatari; i++) {
                    this->ospatari[i] = p.ospatari[i];
                }
            }
        }
        return *this;
    }
    friend ostream& operator<<(ostream& out, PersonalRestaurant& p) {
        out << "\n------------------------------";
        if (p.ospatari != nullptr && p.nrOspatari > 0) {
            out << "\nNr. Produse:" << p.nrOspatari;
            for (int i = 0; i < p.nrOspatari; i++) {
                out << "\nProdus:" << p.ospatari[i];
            }
        }
        else {
            cout << "\nNr.Ospatari=0";
            cout << "\nOspatari:-";
        }
        out << "\n------------------------------";
        return out;
    }
    friend istream& operator>>(istream& in, PersonalRestaurant& p) {
        delete[] p.ospatari;
        p.ospatari = nullptr;
        cout << "nrProduse:";
        in >> p.nrOspatari;
        if (p.nrOspatari <= 0) {
            p.nrOspatari = 0;
            p.ospatari = nullptr;
        }
        else {
            p.ospatari = new Ospatar[p.nrOspatari];
            for (int i = 0; i < p.nrOspatari; i++) {
                cout << "\nprodus:";
                in >> p.ospatari[i];
            }
        }
        return in;
    }

    void demisiepersonal() {
        for (int i = 0; i < this->nrOspatari; i++) {
            this->ospatari[i].demisia();
        }
    }
    ~PersonalRestaurant() {
        delete[] this->ospatari;
        this->ospatari = nullptr;
    }
};

class Meniu {
    Produs* produs = nullptr;
    int nrProduse = 0;
public:
    const int getnrProduse() {
        return this->nrProduse;
    }
    const Produs* getProdus() {
        return this->produs;
    }
    void setNrProduse(int nrProduse, Produs* produs) {
        if (produs != nullptr && nrProduse > 0) {
            delete this->produs;
            this->produs = nullptr;
            this->produs = new Produs[nrProduse];
            this->nrProduse = nrProduse;
            for (int i = 0; i < nrProduse; i++) {
                this->produs[i] = produs[i];
            }
        }
        else throw new ExceptieInput("Produse invalide");
    }

    Meniu() {
        this->produs = nullptr;
        this->nrProduse = 0;
    }
    Meniu(Produs* produs, int nrProduse) {
        if (produs != nullptr && nrProduse > 0) {
            this->produs = new Produs[nrProduse];
            this->nrProduse = nrProduse;
            for (int i = 0; i < nrProduse; i++) {
                this->produs[i] = produs[i];
            }
        }
    }
    Meniu(const Meniu& m) {
        if (m.produs != nullptr && m.nrProduse > 0) {
            this->produs = new Produs[m.nrProduse];
            this->nrProduse = m.nrProduse;
            for (int i = 0; i < m.nrProduse; i++) {
                this->produs[i] = m.produs[i];
            }
        }
    }
    Meniu& operator=(Meniu& m) {
        if (this != &m) {
            delete[] this->produs;
            this->produs = nullptr;
            if (m.produs != nullptr && m.nrProduse > 0) {
                this->produs = new Produs[m.nrProduse];
                this->nrProduse = m.nrProduse;
                for (int i = 0; i < m.nrProduse; i++) {
                    this->produs[i] = m.produs[i];
                }
            }
        }
        return *this;

    }
    int getNrProduse() {
        return this->nrProduse;
    }

    Meniu& operator+(const Produs& produs) {
        Produs* copie = new Produs[this->nrProduse + 1];
        for (int i = 0; i < this->nrProduse; i++) {
            copie[i] = this->produs[i];
        }
        copie[this->nrProduse] = produs;
        this->nrProduse++;
        delete[] this->produs;
        this->produs = nullptr;
        this->produs = copie;
        return *this;
    }


    void adaugaProdus(Produs& produs) {
        Produs* copie = new Produs[this->nrProduse + 1];
        for (int i = 0; i < this->nrProduse; i++) {
            copie[i] = this->produs[i];
        }
        copie[this->nrProduse] = produs;
        this->nrProduse++;
        delete[] this->produs;
        this->produs = nullptr;
        this->produs = copie;

    }
    friend ostream& operator<<(ostream& out, Meniu& m) {
        out << "\n------------------------------";
        if (m.produs != nullptr && m.nrProduse > 0) {
            out << "\nNr. Produse:" << m.nrProduse;
            for (int i = 0; i < m.nrProduse; i++) {
                out << "\nProdus:" << m.produs[i];
            }
        }
        else {
            cout << "\nNr.Produse=0";
            cout << "\nProdus:-";
        }
        out << "\n------------------------------";
        return out;
    }

    friend ofstream& operator<<(ofstream& out, Meniu& m) {

        if (m.produs != nullptr && m.nrProduse > 0) {
            out << "Nr produse: " << m.nrProduse;
            for (int i = 0; i < m.nrProduse; i++) {
                out << "\nProdus " << m.produs[i];
            }
        }

        return out;
    }

    void afisare() {
        cout << "\n------------------------------";
        if (this->produs != nullptr && this->nrProduse > 0) {
            cout << "\nNr. Produse:" << this->nrProduse;
            for (int i = 0; i < this->nrProduse; i++) {
                cout << "\nProdus:" << this->produs[i];
            }
        }
        else {
            cout << "Nr.Produse=0";
            cout << "Produs:-";
        }
        cout << "\n------------------------------";
    }
    friend istream& operator>>(istream& in, Meniu& m) {
        delete[] m.produs;
        m.produs = nullptr;
        cout << "nrProduse:";
        in >> m.nrProduse;
        if (m.nrProduse <= 0) {
            m.nrProduse = 0;
            m.produs = nullptr;
        }
        else {
            m.produs = new Produs[m.nrProduse];
            for (int i = 0; i < m.nrProduse; i++) {
                cout << "\nprodus:";
                in >> m.produs[i];
            }
        }
        return in;
    }
    friend ifstream& operator>>(ifstream& in, Meniu& m) {
        delete[] m.produs;
        m.produs = nullptr;
        in >> m.nrProduse;
        if (m.nrProduse <= 0) {
            m.nrProduse = 0;
            m.produs = nullptr;
        }
        else {
            m.produs = new Produs[m.nrProduse];
            for (int i = 0; i < m.nrProduse; i++) {
                in >> m.produs[i];
            }
        }
        return in;
    }
    void writeToFile(fstream& f2) {

        f2.write((char*)&this->nrProduse, sizeof(int));
        for (int i = 0; i < this->nrProduse; i++) {
            f2.write((char*)&this->produs[i], sizeof(Produs));
        }

    }
    void restoreFromFile(fstream& f1) {
        f1.read((char*)&this->nrProduse, sizeof(int));
        if (this->nrProduse > 0) {
            this->produs = new Produs[this->nrProduse];

            for (int i = 0; i < this->nrProduse; i++) {
                f1.read((char*)&this->produs[i], sizeof(Produs));
            }

        }
        else {
            this->produs = nullptr;
            this->nrProduse = 0;
        }
    }
    void writeToTextFile(ofstream& out) {
        out << "\n------------------------------";
        if (this->produs != nullptr && this->nrProduse > 0) {
            out << "\nNr. Produse:" << this->nrProduse;
            for (int i = 0; i < this->nrProduse; i++) {
                out << "\nProdus:" << this->produs[i];
            }
        }
        else {
            cout << "\nNr.Produse=0";
            cout << "\nProdus:-";
        }
        out << "\n------------------------------";

    }
    void readFromTextFile(ifstream& in) {
        delete[] this->produs;
        this->produs = nullptr;
        cout << "nrProduse:";
        in >> this->nrProduse;
        if (this->nrProduse <= 0) {
            this->nrProduse = 0;
            this->produs = nullptr;
        }
        else {
            this->produs = new Produs[this->nrProduse];
            for (int i = 0; i < this->nrProduse; i++) {
                cout << "\nprodus:";
                in >> this->produs[i];
            }
        }
    }
    ~Meniu() {
        delete[] this->produs;
        this->produs = nullptr;
    }
};
class Comanda {
    const int id;
    string* produs = nullptr;
    int nrProduse = 0;
    static int nrMaximProduse;
public:
    int getId() {
        return this->id;
    }
    const int getnrProduse() {
        return this->nrProduse;
    }
    const string* getProdus() {
        return this->produs;
    }
    static int getNrMaximProduse() {
        return Comanda::nrMaximProduse;
    }
    Comanda(int id) :id(id) {}

    void setNrProduse(int nrProduse, string* produs) {
        if (produs != nullptr && nrProduse > 0 && nrProduse <= Comanda::nrMaximProduse) {
            delete this->produs;
            this->produs = nullptr;
            this->produs = new string[nrProduse];
            this->nrProduse = nrProduse;
            for (int i = 0; i < nrProduse; i++) {
                this->produs[i] = produs[i];
            }
        }
        else throw new ExceptieInput("Produse invalide");
    }
    Comanda() :id(0) {
        this->produs = nullptr;
        this->nrProduse = 0;
        static int nrMaximProduse;
    }
    Comanda(string* produs, int nrProduse, int id) :id(id) {
        if (produs != nullptr && nrProduse > 0 && nrProduse <= Comanda::nrMaximProduse) {
            this->produs = new string[nrProduse];
            this->nrProduse = nrProduse;
            for (int i = 0; i < nrProduse; i++) {
                this->produs[i] = produs[i];
            }
        }
    }
    Comanda(const Comanda& c) :id(c.id) {
        if (c.produs != nullptr && c.nrProduse > 0 && c.nrProduse <= Comanda::nrMaximProduse) {
            this->produs = new string[c.nrProduse];
            this->nrProduse = c.nrProduse;
            for (int i = 0; i < c.nrProduse; i++) {
                this->produs[i] = c.produs[i];
            }
        }
    }
    Comanda& operator=(Comanda& c) {
        delete[] this->produs;
        this->produs = nullptr;
        if (c.produs != nullptr && c.nrProduse > 0 && c.nrProduse <= Comanda::nrMaximProduse) {
            this->produs = new string[c.nrProduse];
            this->nrProduse = c.nrProduse;
            for (int i = 0; i < c.nrProduse; i++) {
                this->produs[i] = c.produs[i];
            }
        }
        return *this;
    }

    friend ostream& operator<<(ostream& out, Comanda& c) {
        out << "\n------------------------------";
        out << "\nid:" << c.id;

        if (c.produs != nullptr && c.nrProduse > 0 && c.nrProduse <= Comanda::nrMaximProduse) {
            out << "\nNr. Produse:" << c.nrProduse;
            for (int i = 0; i < c.nrProduse; i++) {
                out << "\nprodus:" << c.produs[i];
            }
        }
        else {
            out << "\nNr. Produse:-";
            out << "\nProdus:-";
        }
        out << endl << "Nr. Maxim Produse:" << Comanda::nrMaximProduse;
        out << "\n------------------------------";
        return out;
    }

    void afisare() {
        cout << "\n------------------------------";
        cout << "\nid:" << this->id;

        if (this->produs != nullptr && this->nrProduse > 0 && this->nrProduse <= Comanda::nrMaximProduse) {
            cout << "\nNr. Produse:" << this->nrProduse;
            for (int i = 0; i < this->nrProduse; i++) {
                cout << "\nProdus:" << this->produs[i];
            }
        }
        else {
            cout << "\nNr.Produse:-";
            cout << "\nprodus:-";
        }
        cout << endl << "Nr maxim produse:" << Comanda::nrMaximProduse;
        cout << "\n------------------------------";
    }

    friend istream& operator>>(istream& in, Comanda& c) {
        delete[] c.produs;
        c.produs = nullptr;
        cout << "Nr. Produse:";
        in >> c.nrProduse;
        if (c.nrProduse <= 0) {
            c.nrProduse = 0;
            c.produs = nullptr;
        }
        else {
            c.produs = new string[c.nrProduse];
            for (int i = 0; i < c.nrProduse; i++) {
                cout << "\nProdus:";
                in >> c.produs[i];
            }
        }
        return in;
    }
    void adaugaProdusInComanda(string produs) {
        if (this->nrProduse < 4) {
            string* copie;
            copie = new string[this->nrProduse + 1];
            for (int i = 0; i < this->nrProduse; i++) {
                copie[i] = this->produs[i];
            }
            copie[this->nrProduse] = produs;
            this->nrProduse++;
            delete[] this->produs;
            this->produs = nullptr;
            this->produs = copie;
        }
    }
    ~Comanda() {
        delete[] this->produs;
        this->produs = nullptr;
    }

};

int Comanda::nrMaximProduse = 4;

class GestiuneComenzi {
    const int id;
    Comanda* comenzi = nullptr;
    int nrComenzi = 0;
public:
    const int getId() {
        return this->id;
    }
    const Comanda* getComanda() {
        return this->comenzi;
    }
    void setComenzi(int nrComenzi, Comanda* comenzi) {
        if (comenzi != nullptr && nrComenzi > 0) {
            delete this->comenzi;
            this->comenzi = nullptr;
            this->comenzi = new Comanda[nrComenzi];
            this->nrComenzi = nrComenzi;
            for (int i = 0; i < nrComenzi; i++) {
                this->comenzi[i] = comenzi[i];
            }
        }
        else throw new ExceptieInput("Comenzi invalide");
    }
    GestiuneComenzi(int id) :id(id) {}
    GestiuneComenzi(Comanda* comenzi, int nrComenzi, int id) :id(id) {
        if (comenzi != nullptr && nrComenzi > 0) {
            this->comenzi = new Comanda[nrComenzi];
            this->nrComenzi = nrComenzi;
            for (int i = 0; i < nrComenzi; i++) {
                this->comenzi[i] = comenzi[i];
            }
        }
    }
    GestiuneComenzi(const GestiuneComenzi& c) :id(c.id) {
        if (c.comenzi != nullptr && c.nrComenzi > 0) {
            this->comenzi = new Comanda[c.nrComenzi];
            this->nrComenzi = c.nrComenzi;
            for (int i = 0; i < c.nrComenzi; i++) {
                this->comenzi[i] = c.comenzi[i];
            }
        }
    }
    GestiuneComenzi& operator=(GestiuneComenzi& c) {
        delete[] this->comenzi;
        this->comenzi = nullptr;
        if (c.comenzi != nullptr && c.nrComenzi > 0) {
            this->comenzi = new Comanda[c.nrComenzi];
            this->nrComenzi = c.nrComenzi;
            for (int i = 0; i < c.nrComenzi; i++) {
                this->comenzi[i] = c.comenzi[i];
            }
        }
    }
    int getNrComenzi() {
        return this->nrComenzi;
    }
    GestiuneComenzi& operator+(Comanda& comenzi) {
        Comanda* copie = new Comanda[this->nrComenzi + 1];
        for (int i = 0; i < this->nrComenzi; i++) {
            copie[i] = this->comenzi[i];
        }
        copie[this->nrComenzi] = comenzi;
        this->nrComenzi++;
        delete[] this->comenzi;
        this->comenzi = nullptr;
        this->comenzi = copie;
        return *this;
    }

    void adaugaComanda(Comanda& comenzi) {
        Comanda* copie = new Comanda[this->nrComenzi + 1];
        for (int i = 0; i < this->nrComenzi; i++) {
            copie[i] = this->comenzi[i];
        }
        copie[this->nrComenzi] = comenzi;
        this->nrComenzi++;
        delete[] this->comenzi;
        this->comenzi = nullptr;
        this->comenzi = copie;
    }

    void finalulZilei() {
        this->nrComenzi = 0;
        delete[] this->comenzi;
        this->comenzi = nullptr;

    }

    friend ostream& operator<<(ostream& out, const GestiuneComenzi& c) {
        out << "\n------------------------------";
        if (c.comenzi != nullptr && c.nrComenzi > 0) {
            out << "\nNr. Comenzi:" << c.nrComenzi;
            for (int i = 0; i < c.nrComenzi; i++) {
                out << "\nComanda:" << c.comenzi[i];
            }
        }
        else {
            out << "Nr. Comenzi=0";
            out << "Comanda:-";
        }
        out << "\n------------------------------";
        return out;
    }

    void afisare() {
        cout << "\n------------------------------";
        if (this->comenzi != nullptr && this->nrComenzi > 0) {
            cout << "\nnrComenzi:" << this->nrComenzi;
            for (int i = 0; i < this->nrComenzi; i++) {
                cout << "\nComanda:" << this->comenzi[i];
            }
        }
        else {
            cout << "Nr. Comenzi=0";
            cout << "Comanda:-";
        }
        cout << "\n------------------------------";
    }
    friend istream& operator>>(istream& in, GestiuneComenzi& c) {
        delete[] c.comenzi;
        c.comenzi = nullptr;
        cout << "nrProduse:";
        in >> c.nrComenzi;
        if (c.nrComenzi <= 0) {
            c.nrComenzi = 0;
            c.comenzi = nullptr;
        }
        else {
            c.comenzi = new Comanda[c.nrComenzi];
            for (int i = 0; i < c.nrComenzi; i++) {
                cout << "\nprodus:";
                in >> c.comenzi[i];
            }
        }
        return in;
    }
    ~GestiuneComenzi() {
        delete[] this->comenzi;
        this->comenzi = nullptr;
    }
};



int main() {

    Ingredient ou("Ou", 6);
    Ingredient ulei("Ulei", 2);
    Ingredient salam("Salam", 3);
    Ingredient faina("Faina", 2);
    Ingredient sosPaste("Sos Paste", 3);
    Ingredient pasteFainoase("PasteFainoase", 2);
    Ingredient sosRosii("sosRosii", 2);
    Ingredient cascaval("Cascaval", 2);
    Ingredient salataVerde("Salata verde", 2);
    Ingredient castraveti("Castraveti", 2);
    Ingredient* ingrediente_omleta1 = new Ingredient[2];
    ingrediente_omleta1[0] = { ou };
    ingrediente_omleta1[1] = { ulei };

    Ingredient* ingrediente_pizza1 = new Ingredient[4];
    ingrediente_pizza1[0] = { salam };
    ingrediente_pizza1[1] = { faina };
    ingrediente_pizza1[2] = { sosRosii };
    ingrediente_pizza1[3] = { cascaval };

    Ingredient* ingrediente_paste1 = new Ingredient[2];
    ingrediente_paste1[0] = { pasteFainoase };
    ingrediente_paste1[1] = { sosPaste };

    Ingredient* ingrediente_salata1 = new Ingredient[2];
    ingrediente_salata1[0] = { salataVerde };
    ingrediente_salata1[1] = { castraveti };

    int cantitati_omleta[] = { 1,1 };
    int cantitati_pizza[] = { 1,1,1,1 };
    int cantitati_paste[] = { 1,1 };
    int cantitati_salata[] = { 1,1 };
    Produs omleta("Omleta", ingrediente_omleta1, 2, cantitati_omleta);
    Produs pizza("Pizza", ingrediente_pizza1, 4, cantitati_pizza);
    Produs paste("Paste", ingrediente_paste1, 2, cantitati_paste);
    Produs salata("Salata", ingrediente_salata1, 2, cantitati_salata);
    /* cout << ou;
     cout << ulei;
     cout << omleta;*/
    bool disp_omleta = omleta.verificaDisp();
    //cout << disp_omleta;
    bool disp_pizza = pizza.verificaDisp();
    bool disp_paste = paste.verificaDisp();
    bool disp_salata = salata.verificaDisp();
    Produs produse[] = { omleta,pizza,paste,salata };
    Meniu m1(produse, 4);
    /*cout << m1;*/
    Ingredient z("carne", 12);

    //Ingredient* ingrediente_carne = new Ingredient[1];
    //ingrediente_carne[0] = i2;
    //int cantitati_carne[1] = { 1 };
    //Produs carne("Carne", ingrediente_carne, 1, cantitati_carne);
    //Produs p1[] = { carne };
    //Meniu m5(p1, 1);

    //citire si scriere in fisiere binare
    cout << endl << "CITIRE SI SCRIERE IN FISIERE BINARE" << endl;
    fstream file("ing.bin", ios::out | ios::binary);
    z.writeToFile(file);
    file.close();

    fstream file2("ing.bin", ios::in | ios::binary);
    Ingredient ingRez;
    ingRez.restoreFromFile(file2);
    file2.close();
    cout << ingRez;

    fstream file3("produs.bin", ios::out | ios::binary);
    omleta.writeToFile(file3);
    file3.close();

    fstream file4("produs.bin", ios::in | ios::binary);
    Produs pRez;
    pRez.restoreFromFile(file4);
    file3.close();
    cout << pRez;

    //citire si scriere in fisiere text
    cout << endl << "CITIRE SI SCRIERE IN FISIERE TEXT" << endl;
    ofstream f("ing2.txt", ios::out);
    ou.writeToTextFile(f);
    f.close();

    ifstream f1("ing2.txt", ios::in);
    Ingredient ingrez1;
    ingrez1.readFromTextFile(f1);
    f1.close();
    cout << ingrez1;

    ofstream f2("pr.txt", ios::out);
    omleta.writeToTextFile(f2);
    f2.close();

    ifstream f3("pr.txt", ios::in);
    Produs prrez;
    prrez.readFromTextFile(f3);
    f3.close();
    cout << prrez;

    ofstream f4("meniu1.txt", ios::out);
    m1.writeToTextFile(f4);
    f4.close();

    //Rapoarte
    //raport care permite vizualizarea ingredientelor si a stocului
    cout << endl << "RAPOARTE:" << endl;
    vector<Ingredient> v1;
    v1.push_back(ou);
    v1.push_back(ulei);
    v1.push_back(salam);
    v1.push_back(faina);
    ofstream Raport1;
    Raport1.open("ingrediente.txt");
    vector<Ingredient>::iterator itVv;
    for (itVv = v1.begin(); itVv != v1.end(); itVv++) {
        Raport1 << itVv->getNume() << itVv->getCantitate();
    }

  /*  ofstream Raport1;
    Raport1.open("ingrediente.txt");*/

    /*for (auto& in : v1) {
        Raport1 << in.getNume() << in.getCantitate();
    }*/
    Raport1.close();

    vector<Produs> v2;
    v2.push_back(omleta);
    v2.push_back(pizza);
    v2.push_back(salata);
    v2.push_back(paste);

    //raport care permite redarea produselor si numarului de ingrediente necesare
    ofstream Raport2;
    Raport2.open("produse_n.txt");
    vector<Ingredient>::iterator itVv1;
    /*for (itVv1 = v2.begin(); itVv1 != v2.end(); itVv1++) {
        
    }*/
    for (auto& pr : v2) {
        Raport2 << pr.getNume() << endl << pr.getNrIngrediente() << endl;

    }
    Raport2.close();
    vector<Produs> v3;
    v3.push_back(omleta);
    v3.push_back(pizza);
    v3.push_back(salata);
    v3.push_back(paste);
    //raport care permite observarea produselor, ingredientelor si cantitatilor necesare si disponibile
    ofstream Raport3;
    Raport3.open("produse_c.txt");
    for (auto& pc : v3) {
        Raport3 << pc.getNume() << endl;

        for (int i = 0; i < pc.getNrIngrediente(); i++) {
            Raport3 << pc.getRetetar()[i];
            Raport3 << pc.getCantitati()[i] << endl;

        }
    }
    Raport3.close();
    Comanda c1(1);
    //mostenire
    cout << endl << "MOSTENIRE:" << endl;
    Angajat ang("Ana", "chelner", 3, 30);
    Angajat ang1("Anton", "manager", 10, 40);
    cout << ang;
    Ospatar os("Mirel", "ospatar", 2, 30, 12, 20);
    cout << os;

    cout << endl << "Calcul nr zile concediu pt angajat: " << ang.zileConcediu();
    cout << endl << "Calcul nr zile concediu pt ospatar: " << os.zileConcediu();


    fstream file6("angajat.bin", ios::out | ios::binary);
    ang.writeToFile(file6);
    file6.close();
    fstream file7("angajat.bin", ios::in | ios::binary);
    Angajat angRez;
    angRez.restoreFromFile(file7);
    file7.close();
    cout << angRez;
    cout << endl << "LISTA" << endl;
    //list 
    list<Ingredient> listaI;
    listaI.push_back(ou);
    listaI.push_back(faina);
    list<Ingredient>::iterator itList;
    for (itList = listaI.begin(); itList != listaI.end(); itList++) {
        cout << endl << itList->getNume() << " " << itList->getCantitate();
    }
    cout << endl << "VECTOR" << endl;
    //vector
    vector<Ingredient> vIn;
    vIn.push_back(ou);
    vIn.push_back(faina);
    vector<Ingredient>::iterator itV;
    for (itV = vIn.begin(); itV != vIn.end(); itV++) {
        cout << endl << itV->getNume() << " " << itV->getCantitate();
    }
    cout << endl << "MAP" << endl;
    //map
    map<string, Ingredient> mIn;
    mIn["Ingredient 1 "] = ou;
    mIn["Ingredient 2 "] = faina;
    map<string, Ingredient>::iterator itM;
    for (itM = mIn.begin(); itM != mIn.end(); itM++) {
        cout << endl << itM->first << " " << (itM->second).getNume() << " " << itM->second.getCantitate();
    }
    ou.exportCSV(2, ingrediente_omleta1);

    cout << "-----------------------";

    //set
  /*  set<Ingredient> setIn;
    setIn.insert(ou);
    setIn.insert(faina);
    set<Ingredient>::iterator itSet;
    for (itSet = setIn.begin(); itSet != setIn.end(); itSet++) {
        cout << *itSet << " ";
    }*/
    /* itSet = setIn.find(faina);
     if (itSet != setIn.end()) {
         cout << "s-a gasit in set.";
     }
     else {
         cout << "nu s-a gasit";
     }*/

    string produs[10];
    int i = 0;
    int max = Comanda::getNrMaximProduse();
    cout << "\nAlegeti operatiunea: ";
    cout << "\nPentru afisarea meniului scrieti: afiseaza_meniul";
    cout << "\nPentru comanda scrieti: comanda\n";
    string actiune;
    cin >> actiune;
    if (actiune == "afiseaza_meniul") {
        cout << m1;
        cout << endl << "Doriti sa comandati? Daca da, tastati 'comanda'. Daca nu, tastati 'STOP'";
        cin >> actiune;

    }
    if (actiune == "comanda") {
        cout << "\nAdaugati produs din lista: pizza, paste, omleta, salata";
        cout << "\nLa final scrieti STOP ";
        int ct = 0;
        int ct1 = 0;
        int ct2 = 0;
        int ct3 = 0;

        while (i < max) {
            cout << "\nProdus: ";
            cin >> produs[i];

            if (produs[i] == "omleta") {

                if (disp_omleta == 1) {// verific daca e cantitatea initiala necesara disponibila

                    if (ct == 0) {//verific daca s-a consumat si daca da, daca mai avem de ajuns


                        int* cantitate1 = omleta.operator- (ingrediente_omleta1);
                        /*for (int i = 0; i < omleta.getNrIngrediente(); i++) {
                            cout << endl << cantitate1[i];
                        }*/

                        cout << "\nProdus adaugat in comanda\n ";
                        c1.adaugaProdusInComanda(produs[i]);
                        for (int i = 0; i < omleta.getNrIngrediente(); i++) {
                            if (cantitate1[i] == 0) { ct = ct + 1; break; }
                        }
                    }
                    else if (ct != 0) {
                        cout << "\nStoc indisponibil pt produs\n ";
                    }
                }
                else {
                    cout << "\nStoc indisponibil pt produs\n ";
                }
            }
            if (produs[i] == "pizza") {
                if (disp_pizza == 1) {
                    if (ct1 == 0) {

                        int* cantitate2 = pizza.operator- (ingrediente_pizza1);
                        //for (int i = 0; i < pizza.getNrIngrediente(); i++) {
                        //    cout << endl << cantitate2[i];
                        //}
                        cout << "\nProdus adaugat in comanda\n ";
                        c1.adaugaProdusInComanda(produs[i]);
                        for (int i = 0; i < pizza.getNrIngrediente(); i++) {
                            if (cantitate2[i] == 0) { ct1 = ct1 + 1; break; }
                        }
                    }
                    else if (ct1 != 0) {
                        cout << "\nStoc indisponibil pt produs\n ";
                    }
                }
                else {
                    cout << "\nStoc indisponibil pt produs\n ";
                }
            }
            if (produs[i] == "paste") {
                if (disp_paste == 1) {
                    if (ct2 == 0) {

                        int* cantitate3 = paste.operator- (ingrediente_paste1);
                        /*for (int i = 0; i < paste.getNrIngrediente(); i++) {
                            cout << endl << cantitate3[i];
                        }*/
                        c1.adaugaProdusInComanda(produs[i]);
                        cout << "\nProdus adaugat in comanda\n ";
                        for (int i = 0; i < paste.getNrIngrediente(); i++) {
                            if (cantitate3[i] == 0) { ct2 = ct2 + 1; break; }
                        }
                    }
                    else if (ct2 != 0) {
                        cout << "\nStoc indisponibil pt produs\n ";
                    }
                }
                else {

                    cout << "\nStoc indisponibil pt produs\n ";

                }
            }
            if (produs[i] == "salata") {
                if (disp_salata == 1) {
                    if (ct3 == 0) {

                        int* cantitate4 = salata.operator- (ingrediente_salata1);
                        /*for (int i = 0; i < salata.getNrIngrediente(); i++) {
                            cout << endl << cantitate4[i];
                        }*/
                        cout << "\nProdus adaugat in comanda\n ";
                        c1.adaugaProdusInComanda(produs[i]);
                        for (int i = 0; i < salata.getNrIngrediente(); i++) {
                            if (cantitate4[i] == 0) { ct3 = ct3 + 1; break; }
                        }
                    }
                    else if (ct3 != 0) {
                        cout << "\nStoc indisponibil pt produs\n ";
                    }
                }
                else {
                    cout << "\nStoc indisponibil pt produs\n ";
                }
            }
            if (produs[i] == "STOP") {
                i = 4;
            }

            i++;
        }
        cout << "\nComanda:" << c1;


    }
    GestiuneComenzi g1(1);
    g1 + c1;
    cout << "\nGestiune comenzi:" << g1;
    return 0;
}
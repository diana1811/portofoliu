﻿

document.addEventListener("DOMContentLoaded", aplicatie);

let data = [];
const tooltip = document.createElement("div");

function aplicatie() {
    pregatireToolTip();
    preluareDateDinJson()
        .then(() => {
            adaugareDateInSelect();
            primeleGrafice();
            tabelCulori(getAnSelect());
            setupEvenimente();
        })
        .catch(err => console.error("Eroare la încărcarea datelor:", err));
}

async function preluareDateDinJson() {
    const raspuns = await fetch("./media/eurostat.json");
    data = await raspuns.json();
}

function pregatireToolTip() {
    tooltip.style.position = "absolute";
    tooltip.style.backgroundColor = "rgba(166, 124, 82, 0.7)"; 
    tooltip.style.color = "white"; 
    tooltip.style.padding = "10px"; 
    tooltip.style.borderRadius = "8px";
    tooltip.style.boxShadow = "0px 4px 8px rgba(0, 0, 0, 0.3)"; 
    tooltip.style.fontFamily = "Arial, sans-serif"; 
    tooltip.style.fontSize = "14px"; 
    tooltip.style.pointerEvents = "none";
    tooltip.style.visibility = "hidden";
    document.body.appendChild(tooltip);
}


function adaugareDateInSelect() {
    const tari = [];
    const ani = [];

    for (let i = 0; i < data.length; i++) {
        const tara = data[i].tara;
        const an = data[i].an;

        if (!tari.includes(tara)) {
            tari.push(tara);
        }

        if (!ani.includes(an)) {
            ani.push(an);
        }
    }

    ani.sort(); 

    const taraInSelect = document.getElementById("tara");
    const anInSelect = document.getElementById("an");

    taraInSelect.innerHTML = "";
    anInSelect.innerHTML = "";

    for (let i = 0; i < tari.length; i++) {
        const o = document.createElement("option");
        o.textContent = tari[i];
        taraInSelect.appendChild(o); 
    }

    for (let i = 0; i < ani.length; i++) {
        const o = document.createElement("option");
        o.textContent = ani[i]; 
        anInSelect.appendChild(o); 
    }
}

function getTaraSelect() {
    return document.getElementById("tara").value;
}

function getIndicatorSelect() {
    return document.getElementById("indicator").value;
}

function getAnSelect() {
    return document.getElementById("an").value;
}
function primeleGrafice() {
    const tara = getTaraSelect();
    const indicator = getIndicatorSelect();
    const an = getAnSelect();

    desenGraficLinie(tara, indicator);
    desenGraficBubble(an);
}

function setupEvenimente() {
    const taraSelectata = document.getElementById("tara");
    const indicatorSelectat = document.getElementById("indicator");
    const anSelectat = document.getElementById("an");
    const btnAnimatie = document.querySelector("#btnAnimatie");
    const indicatorXSelectat = document.getElementById("indicatorX");
    const indicatorYSelectat = document.getElementById("indicatorY");
    const indicatorMarimeBula = document.getElementById("sizeIndicator");
    taraSelectata.addEventListener("change", () => {
        desenGraficLinie(getTaraSelect(), getIndicatorSelect());
    });

    indicatorSelectat.addEventListener("change", () => {
        desenGraficLinie(getTaraSelect(), getIndicatorSelect());
    });

    anSelectat.addEventListener("change", () => {
        desenGraficBubble(getAnSelect());
        tabelCulori(getAnSelect());
    });
    indicatorXSelectat.addEventListener("change", () => {
        desenGraficBubble(getAnSelect());
    });

    indicatorYSelectat.addEventListener("change", () => {
        desenGraficBubble(getAnSelect());
    });

    indicatorMarimeBula.addEventListener("change", () => {
        desenGraficBubble(getAnSelect());
    });
    btnAnimatie.addEventListener("click", () => {
        animatie();
    });
}

//exercitiul 2+3- grafic linie evolutie - grafica vectoriala+tooltip
function desenGraficLinie(tara, indicator) {
    const svgChart = document.getElementById("line-chart");
    const dateFiltrate = data.filter(item => item.tara === tara && item.indicator === indicator);
    if (dateFiltrate.length === 0) {
        svgChart.innerHTML = "<text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle'>Nu există date disponibile</text>";
        return;
    }
    const valori = dateFiltrate.map(item => parseFloat(item.valoare) || 0);
    const ani = dateFiltrate.map(item => item.an);

    svgChart.innerHTML = "";
    const svgNS = "http://www.w3.org/2000/svg";
    const width = 600;
    const height = 400;
    const padding = 40;

    const axaX = document.createElementNS(svgNS, "line");
    axaX.setAttribute("x1", padding);
    axaX.setAttribute("y1", height - padding);
    axaX.setAttribute("x2", width - padding);
    axaX.setAttribute("y2", height - padding);
    axaX.setAttribute("stroke", "black");

    const axaY = document.createElementNS(svgNS, "line");
    axaY.setAttribute("x1", padding);
    axaY.setAttribute("y1", height - padding);
    axaY.setAttribute("x2", padding);
    axaY.setAttribute("y2", padding);
    axaY.setAttribute("stroke", "black");

    svgChart.appendChild(axaX);
    svgChart.appendChild(axaY);

    valMax = Math.max(...valori);
    valMin = Math.min(...valori);

    const xS = (width - 2 * padding) / (ani.length - 1);
    const yS = (height - 2 * padding) / (valMax - valMin);

    const linieTrend = document.createElementNS(svgNS, "polyline");
    linieTrend.setAttribute("stroke", "#a67c52"); 
    linieTrend.setAttribute("stroke-width", 2);
    linieTrend.setAttribute("fill", "none");
    const puncte = valori.map((val, index) => {
        const x = padding + index * xS;
        const y = height - padding - (val - valMin) * yS;
        return `${x},${y}`;
    }).join(" ");
    linieTrend.setAttribute("points", puncte);
    svgChart.appendChild(linieTrend);

    svgChart.addEventListener("mousemove", (e) => {
        const rect = svgChart.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const index = Math.round((x - padding) / xS);
        if (index > 0 && index < ani.length) {
            const an = ani[index];
            const val = valori[index];
            tooltip.textContent = `An: ${an}, Valoare: ${val}`;
            tooltip.style.left = `${e.clientX + 10}px`;
            tooltip.style.top = `${e.clientY + 10}px`;
            tooltip.style.visibility = "visible";
        } else {
            tooltip.style.visibility = "hidden";

        }
    });
    svgChart.addEventListener("mouseleave", () => {
        tooltip.style.visibility = "hidden";
    });

}
function getIndicatorX() {
    return document.getElementById("indicatorX").value;
}

function getIndicatorY() {
    return document.getElementById("indicatorY").value;
}

function getMarimeBula() {
    return document.getElementById("sizeIndicator").value;
}

//exercitiul 4 - bubble chart - grafica raster
function desenGraficBubble(an) {
    const canvas = document.getElementById("canvas-chart");
    const context = canvas.getContext("2d");

    const indicatorX = getIndicatorX();
    const indicatorY = getIndicatorY();
    const marimeBula = getMarimeBula();

    context.clearRect(0, 0, canvas.width, canvas.height);

    const width = canvas.width;
    const height = canvas.height;
    const padding = 50;
    const dataX = [];
    const dataY = [];
    const dataMarimeBula = [];
    const tari = [];
    const bule = []; 
    pregatireToolTip();
    context.beginPath();
    context.moveTo(padding, height - padding);
    context.lineTo(width - padding, height - padding);
    context.moveTo(padding, height - padding);
    context.lineTo(padding, padding);
    context.strokeStyle = "black";
    context.stroke();

    for (let i = 0; i < data.length; i++) {
        const inreg = data[i];
        if (inreg.an === an) {
            if (inreg.indicator === indicatorX) {
                dataX.push(inreg);
            }
            if (inreg.indicator === indicatorY) {
                dataY.push(inreg);
            }
            if (inreg.indicator === marimeBula) {
                dataMarimeBula.push(inreg);
            }
            if (!tari.includes(inreg.tara)) {
                tari.push(inreg.tara);
            }
        }
    }

    if (tari.length === 0) {
        context.font = "20px Arial";
        context.fillStyle = "black";
        context.textAlign = "center";
        context.fillText("Nu există date pentru anul selectat", width / 2, height / 2);
        return;
    }

    let minX = Infinity, maxX = -Infinity;
    let minY = Infinity, maxY = -Infinity;
    let minMarime = Infinity, maxMarime = -Infinity;

    for (let i = 0; i < dataX.length; i++) {
        const val = parseFloat(dataX[i].valoare);
        if (val > maxX) {
            maxX = val
        };
        if (val < minX) {
            minX = val
        };
    }
    for (let i = 0; i < dataY.length; i++) {
        const val = parseFloat(dataY[i].valoare);
        if (val > maxY) {
            maxY = val
        };
        if (val < minY) {
            minY = val
        };
    }
    for (let i = 0; i < dataMarimeBula.length; i++) {
        const val = parseFloat(dataMarimeBula[i].valoare);
        if (val > maxMarime) {
            maxMarime = val
        };
        if (val < minMarime) {
            minMarime = val
        };
    }

    const scalareX = val => padding + (((val - minX) / (maxX - minX) *0.8) * (width - 2 * padding) + 0.1 * (width - 2 * padding));
    const scalareY = val => height - padding - (((val - minY) / (maxY - minY)*0.8) * (height - 2 * padding) + 0.1 * (width - 2 * padding));

    for (let i = 0; i < tari.length; i++) {
        const tara = tari[i];
        let xVal = null;
        let yVal = null;
        let marimeVal = null;

        for (let j = 0; j < dataX.length; j++) {
            if (dataX[j].tara === tara) {
                xVal = parseFloat(dataX[j].valoare);
                break;
            }
        }
        for (let j = 0; j < dataY.length; j++) {
            if (dataY[j].tara === tara) {
                yVal = parseFloat(dataY[j].valoare);
                break;
            }
        }
        for (let j = 0; j < dataMarimeBula.length; j++) {
            if (dataMarimeBula[j].tara === tara) {
                marimeVal = parseFloat(dataMarimeBula[j].valoare);
                break;
            }
        }

        if (xVal !== null && yVal !== null && marimeVal !== null) {
            const x = scalareX(xVal);
            const y = scalareY(yVal);
            const marime = Math.max(Math.sqrt(marimeVal / maxMarime) * 50, 10);

            const color = "rgba(166, 124, 82, 0.7)";
            context.beginPath();
            context.arc(x, y, marime, 0, 2 * Math.PI);
            context.fillStyle = color;
            context.fill();
            context.strokeStyle = "#a67c52";
            context.stroke();

            context.fillStyle = "black";
            context.font = "12px Arial";
            context.textAlign = "center";
            context.fillText(tara, x, y + 4);
            bule.push({ x, y, marime, tara, xVal, yVal, marimeVal });

        }
    }
    canvas.addEventListener("mousemove", e => {
        const rect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        let gasit = false;
        for (const bula of bule) {
            const dist = Math.sqrt(Math.pow(mouseX - bula.x, 2) + Math.pow(mouseY - bula.y, 2));
            if (dist <= bula.marime) {
                tooltip.style.left = `${e.pageX + 10}px`;
                tooltip.style.top = `${e.pageY + 10}px`;
                tooltip.style.visibility = "visible";
                tooltip.innerHTML = `
                    <strong>${bula.tara}</strong><br>
                    ${indicatorX}: ${bula.xVal.toFixed(2)}<br>
                    ${indicatorY}: ${bula.yVal.toFixed(2)}<br>
                    ${marimeBula}: ${bula.marimeVal.toFixed(2)}`;
                gasit = true;
                break;
            }
        }

        if (!gasit) {
            tooltip.style.visibility = "hidden";
        }
    });

    canvas.addEventListener("mouseleave", () => {
        tooltip.style.visibility = "hidden";
    });
    
}

//exercitiul 5 - animatie bubble chart
function animatie() {
    const ani = data.map(item => item.an);
    const aniU = [];
    for (let i = 0; i < ani.length; i++) {
        if (!aniU.includes(ani[i])) {
            aniU.push(ani[i]);
        }
    }
    aniU.sort();
    let i = 0;
    function bubbleNext() {
        if (i >= aniU.length) {
            return;
        }
        const an = aniU[i];
        desenGraficBubble(an);
        const afisareAn = document.getElementById("year-display");
        if (afisareAn) {
            afisareAn.textContent = `Anul din animație: ${an}`;
        }
        i++;
        setTimeout(bubbleNext, 1000);
    }
    bubbleNext();
}

//exercitiul 6 - tabel
function tabelCulori(an) {
    const tbody = document.querySelector("#data-table tbody");
    const dateFiltrate = data.filter(item => item.an === an);
    const yTable = document.querySelector("#year-table");
    yTable.textContent = `An: ${an}`;
    const tari = [];
    dateFiltrate.forEach(item => {
        if (!tari.includes(item.tara)) {
            tari.push(item.tara);
        }
    });

    const indicatori = ["PIB", "SV", "POP"];
    const medii = {};
    for (let i = 0; i < indicatori.length; i++) {
        let suma = 0;
        let k = 0;
        dateFiltrate.forEach(item => {
            if (item.indicator === indicatori[i] && item.valoare) {
                suma = suma + parseFloat(item.valoare);
                k++;
            }
        });
        if (k > 0) {
            medii[indicatori[i]] = suma / k;
        }
        else {
            medii[indicatori[i]] = 0;
        }
    }
    tbody.innerHTML = "";
    tari.forEach(tara => {
        const rand = document.createElement("tr");
        const celulaTara = document.createElement("td");
        celulaTara.textContent = tara;
        rand.appendChild(celulaTara);
        indicatori.forEach(indicator => {
            const celulaIndicator = document.createElement("td");
            let val = "-";
            dateFiltrate.forEach(item => {
                if (item.tara === tara && item.indicator === indicator) {
                    val = parseFloat(item.valoare);
                }
            });
                if (isNaN(val)) {
                    celulaIndicator.textContent = "Nu există date";
                } else {
                    celulaIndicator.textContent = val.toFixed(2);
                }
                if (val !== "-") {
                    const diferenta = Math.abs(val - medii[indicator]);
                    let maxDif = 0;
                    dateFiltrate.forEach(item => {
                        if (item.indicator === indicator && item.valoare) {
                            const curentDif = Math.abs(parseFloat(item.valoare) - medii[indicator]);
                            if (curentDif > maxDif) maxDif = curentDif;
                        }
                    });
                    const intensitate = maxDif > 0 ? Math.round((diferenta / maxDif) * 255) : 0;
                    const culoare = `rgb(${intensitate}, ${255 - intensitate}, 0)`;
                    celulaIndicator.style.backgroundColor = culoare;
                    celulaIndicator.style.color = "black";
                }
            rand.appendChild(celulaIndicator);
        });
        tbody.appendChild(rand);
    });
}
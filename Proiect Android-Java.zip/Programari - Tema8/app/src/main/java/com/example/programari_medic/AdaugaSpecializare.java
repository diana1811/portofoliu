package com.example.programari_medic;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AdaugaSpecializare extends AppCompatActivity {

    EditText etDenumire;
    EditText etDescriere;
    Button btnAdaugaSpecializare;
    private boolean isEditing = false;
    private Specializare specializareToEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adauga_specializare);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etDenumire = findViewById(R.id.etAdaugaDenumireSp);
        etDescriere = findViewById(R.id.etAdaugaDescriere);
        btnAdaugaSpecializare = findViewById(R.id.btnAddSp);

        ProgramariDB dbInstance = ProgramariDB.getInstance(getApplicationContext());

        Intent editIntent = getIntent();
        if (editIntent.hasExtra("edit")) {
            isEditing = true;
            specializareToEdit = (Specializare) editIntent.getSerializableExtra("edit");
            etDenumire.setText(specializareToEdit.getDenumire());
            etDescriere.setText(specializareToEdit.getDescriere());
        }

        btnAdaugaSpecializare.setOnClickListener(view -> {
            String den = etDenumire.getText().toString();
            String des = etDescriere.getText().toString();

            if (den.isEmpty() || des.isEmpty()) {
                Toast.makeText(this, "Toate câmpurile sunt obligatorii!", Toast.LENGTH_SHORT).show();
                return;
            }
            Specializare specializare=new Specializare(den,des);


            SharedPreferences sharedPreferences = getSharedPreferences("local", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("ultimaSpecializare", den);
            editor.apply();
            if (isEditing) {
                specializare.setIdSpecializare(specializareToEdit.getIdSpecializare());
                dbInstance.getSpecializareDAO().updateDescriereSpecializare(specializare.getIdSpecializare(),specializare.getDescriere());
                Toast.makeText(AdaugaSpecializare.this, "Specializare actualizată cu succes!", Toast.LENGTH_SHORT).show();
            } else {
                dbInstance.getSpecializareDAO().insertSpecializare(specializare);
                Toast.makeText(AdaugaSpecializare.this, "Medic adăugat cu succes!", Toast.LENGTH_SHORT).show();
            }


            Intent resultIntent = new Intent();
            resultIntent.putExtra("specializareFromIntent", specializare);
            isEditing=false;
            setResult(RESULT_OK, resultIntent);
            finish();

        });

    }
}

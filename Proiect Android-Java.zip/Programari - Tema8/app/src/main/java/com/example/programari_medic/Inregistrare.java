package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Inregistrare extends AppCompatActivity {

    EditText numeInreg;
    EditText prenumeInreg;
    EditText telefonInreg;
    EditText localitateInreg;
    EditText dataNastere;
    Button btnInreg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inregistrare);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        numeInreg = findViewById(R.id.etNumeInreg);
        prenumeInreg = findViewById(R.id.etPrenumeInreg);
        telefonInreg = findViewById(R.id.etTelefonInreg);
        localitateInreg = findViewById(R.id.etLocalitateInreg);
        dataNastere = findViewById(R.id.etDataInreg);
        btnInreg = findViewById(R.id.btnInregistreaza);

        ProgramariDB dbInstance = ProgramariDB.getInstance(getApplicationContext());

        btnInreg.setOnClickListener(view -> {
            String nume = numeInreg.getText().toString();
            String prenume = prenumeInreg.getText().toString();
            String telefon = telefonInreg.getText().toString();
            String localitate = localitateInreg.getText().toString();
            Date dataPreluata = null;

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            try {
                dataPreluata = sdf.parse(dataNastere.getText().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (nume.isEmpty() || prenume.isEmpty() || telefon.isEmpty() || localitate.isEmpty() || dataPreluata == null) {
                Toast.makeText(Inregistrare.this, "Te rog completează toate câmpurile!", Toast.LENGTH_SHORT).show();
            } else {
                Client client = new Client(nume, dataPreluata, localitate, telefon, prenume);

                dbInstance.getClientDAO().insertClient(client);

                Toast.makeText(Inregistrare.this, "Client înregistrat cu succes!", Toast.LENGTH_SHORT).show();


                Intent resultIntent = new Intent();
                resultIntent.putExtra("clientFromIntent", client);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}

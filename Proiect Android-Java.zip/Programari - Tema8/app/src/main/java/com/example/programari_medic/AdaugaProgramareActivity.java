package com.example.programari_medic;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class AdaugaProgramareActivity extends AppCompatActivity {

    private Spinner spinnerClinica, spinnerMedic, spinnerSpecializare;
    private EditText etCerinteSpeciale, etDataProgramare;
    private Button btnSalveaza;
    private ProgramariDB dbInstance;
    private ListView lvprog;
    private Button btnBackToMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adauga_programare);

        dbInstance=ProgramariDB.getInstance(getApplicationContext());

        spinnerClinica = findViewById(R.id.spinnerClinica);
        spinnerMedic = findViewById(R.id.spinnerMedic);
        spinnerSpecializare = findViewById(R.id.spinnerSpecializare);
        etCerinteSpeciale = findViewById(R.id.etCerinteSpeciale);
        etDataProgramare = findViewById(R.id.etDataProgramare);
        btnSalveaza = findViewById(R.id.btnSalveaza);
        lvprog=findViewById(R.id.lvprog);
        configureSpinners();
        loadProgramari();
        etDataProgramare.setOnClickListener(v -> showDatePicker());
        btnBackToMain=findViewById(R.id.btnBackInMain);
        btnSalveaza.setOnClickListener(v -> salveazaProgramare());
        btnBackToMain.setOnClickListener(view->{
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });
    }

    private void configureSpinners() {
        List<Clinica> clinici = dbInstance.getClinicaDAO().getAllClinici();
        List<Specializare> listaSpecializari = dbInstance.getSpecializareDAO().getAllSpecializari();
        List<Medic> listaMedici=dbInstance.getMedicDAO().getAllMedici();
        ArrayAdapter<Clinica> adapterClinici = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, clinici);
        spinnerClinica.setAdapter(adapterClinici);

        ArrayAdapter<Specializare> adapterSpecializari = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, listaSpecializari);
        spinnerSpecializare.setAdapter(adapterSpecializari);

        ArrayAdapter<Medic> adapterMedici=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, listaMedici);
        spinnerMedic.setAdapter(adapterMedici);
        spinnerClinica.setAdapter(adapterClinici);

        spinnerSpecializare.setAdapter(adapterSpecializari);
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            etDataProgramare.setText(selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear);
        }, year, month, day);

        datePickerDialog.show();
    }

    private void salveazaProgramare() {

        Clinica clinica = (Clinica)spinnerClinica.getSelectedItem();
        Medic medic = (Medic)spinnerMedic.getSelectedItem();
        Specializare specializare = (Specializare)spinnerSpecializare.getSelectedItem();
        String cerinteSpeciale = etCerinteSpeciale.getText().toString();
        String dataProgramareString = etDataProgramare.getText().toString();

        Date dataProgramare;
        try {
            dataProgramare = new Date(dataProgramareString);
        } catch (Exception e) {
            Toast.makeText(this, "Dată invalidă!", Toast.LENGTH_SHORT).show();
            return;
        }
        SharedPreferences sharedPreferences=getSharedPreferences("LOCAL", MODE_PRIVATE);
        int id=sharedPreferences.getInt("token", -1);
        Programare programare = new Programare(clinica.getIdClinica(), medic.getIdMedic(), dataProgramare, cerinteSpeciale, specializare.getIdSpecializare(),id);
        dbInstance.getProgramareDAO().insertProgramare(programare);

        Toast.makeText(this, "Programare salvată cu succes!", Toast.LENGTH_SHORT).show();
        loadProgramari();
    }
    private void loadProgramari() {
        SharedPreferences sharedPreferences=getSharedPreferences("LOCAL", MODE_PRIVATE);
        int id=sharedPreferences.getInt("token", 0);
        List<Programare> programari = dbInstance.getProgramareDAO().getProgramariByClient(id);

        if (programari != null && !programari.isEmpty()) {
            ArrayAdapter<Programare> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, programari);
            lvprog.setAdapter(adapter);
        } else {
            lvprog.setAdapter(null);
            Toast.makeText(this, "Nu există programări salvate!", Toast.LENGTH_SHORT).show();
        }
    }

}

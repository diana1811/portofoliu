package com.example.programari_medic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.programari_medic.Programare;

import java.util.List;

@Dao
public interface ProgramareDAO {

    @Insert
    void insertProgramare(Programare programare);

    @Query("SELECT * FROM programari")
    List<Programare> getAllProgramari();

    @Delete
    void deleteProgramare(Programare programare);
    @Query("SELECT * FROM programari WHERE idMedic = :medic AND idClinica = :clinica")
    List<Programare> getProgramariByMedicAndDate(int medic, int clinica);
    @Update
    void updateProgramare(Programare programare);

    @Query("UPDATE programari SET cerinteSpeciale = :cerinteSpeciale WHERE idProgramare = :idProgramare")
    void updateOraProgramare(int idProgramare, String cerinteSpeciale);
    @Query("DELETE FROM recenzii WHERE idRecenzie = :idRecenzie")
    void deleteRecenzieById(int idRecenzie);
    @Query("SELECT * FROM programari WHERE idClient = :idClient")
    List<Programare> getProgramariByClient (int idClient);

}
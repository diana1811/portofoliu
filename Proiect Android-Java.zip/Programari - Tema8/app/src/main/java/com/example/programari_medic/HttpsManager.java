package com.example.programari_medic;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class HttpsManager {
    private String url;
    private BufferedReader bufferedReader;
    private HttpsURLConnection connection;

    public HttpsManager(String url) {
        this.url = url;
    }

    public String procesare(){
        try {
            return preluareJsonHttps();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        finally{
            inchidereConexiuni();
        }
    }

    public void inchidereConexiuni() {
        try {
            if (bufferedReader != null) {
                bufferedReader.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (connection != null) {
            connection.disconnect();
        }
    }
    public String preluareJsonHttps() throws IOException {
        try {
            connection = (HttpsURLConnection) new URL(url).openConnection();
            bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String linie;
            while ((linie = bufferedReader.readLine()) != null) {
                sb.append(linie);
            }
            return sb.toString();
        } finally {
            inchidereConexiuni();
        }
    }
}

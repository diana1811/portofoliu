package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class AdaugaNota extends AppCompatActivity {

    Button btnAdaugaNota;
    EditText etAdaugaNota;
    Button btnBackN;
    Spinner spClientn;
    Spinner spMedicn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adauga_nota);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnAdaugaNota = findViewById(R.id.btnTrimiteNota);
        etAdaugaNota = findViewById(R.id.etAddNota);
        btnBackN = findViewById(R.id.btnBackN);
        spClientn = findViewById(R.id.spinnerClientNota);
        spMedicn = findViewById(R.id.spinnerMedicNota);

        ProgramariDB dbInstance = ProgramariDB.getInstance(getApplicationContext());

        List<Client> clienti = dbInstance.getClientDAO().getAllClienti();

        ArrayAdapter<Client> adapterClienti = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, clienti);
        spClientn.setAdapter(adapterClienti);

        List<Medic> medici = dbInstance.getMedicDAO().getAllMedici();

        ArrayAdapter<Medic> adapterMedici = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, medici);
        spMedicn.setAdapter(adapterMedici);

        btnAdaugaNota.setOnClickListener(view -> {
            int notan;
            Client client;
            Medic medic;

            notan = Integer.parseInt(etAdaugaNota.getText().toString());

            client = (Client) spClientn.getSelectedItem();
            medic = (Medic) spMedicn.getSelectedItem();

            Nota nota = new Nota(notan, medic.getIdMedic(), client.getIdClient());
            dbInstance.getNotaDAO().insertNota(nota);

            Toast.makeText(this, "Nota adăugată cu succes!", Toast.LENGTH_LONG).show();
        });

        btnBackN.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });
    }
}

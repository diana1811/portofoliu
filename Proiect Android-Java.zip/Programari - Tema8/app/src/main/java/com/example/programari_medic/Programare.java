package com.example.programari_medic;

import android.widget.SimpleAdapter;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.text.SimpleDateFormat;
import java.util.Date;
@Entity(  tableName = "programari",  foreignKeys = {@ForeignKey(
        entity = Medic.class,
        parentColumns = "idMedic",
        childColumns = "idMedic",
        onDelete = ForeignKey.CASCADE
), @ForeignKey(
        entity = Clinica.class,
        parentColumns = "idClinica",
        childColumns = "idClinica",
        onDelete = ForeignKey.CASCADE
)})
public class Programare {
    @PrimaryKey(autoGenerate = true)
    int idProgramare;
    int idClinica;
    int idClient;
    int idMedic;
    Date dataProgramare;
    String cerinteSpeciale;
    int idSpecializare;

    public Programare( int idClinica, int idMedic, Date dataProgramare, String cerinteSpeciale, int idSpecializare,int idClient) {

        this.idClinica = idClinica;
        this.idMedic = idMedic;
        this.dataProgramare = dataProgramare;
        this.cerinteSpeciale = cerinteSpeciale;
        this.idSpecializare = idSpecializare;
        this.idClient=idClient;
    }

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    public void setIdProgramare(int idProgramare) {
        this.idProgramare = idProgramare;
    }

    public int getIdProgramare() {
        return idProgramare;
    }


    public int getIdClinica() {
        return idClinica;
    }

    public void setIdClinica(int idClinica) {
        this.idClinica = idClinica;
    }

    public int getIdMedic() {
        return idMedic;
    }

    public void setIdMedic(int idMedic) {
        this.idMedic = idMedic;
    }

    public String getCerinteSpeciale() {
        return cerinteSpeciale;
    }

    public void setCerinteSpeciale(String cerinteSpeciale) {
        this.cerinteSpeciale = cerinteSpeciale;
    }

    public Date getDataProgramare() {
        return dataProgramare;
    }

    public void setDataProgramare(Date dataProgramare) {
        this.dataProgramare = dataProgramare;
    }

    public int getIdSpecializare() {
        return idSpecializare;
    }

    public void setIdSpecializare(int idSpecializare) {
        this.idSpecializare = idSpecializare;
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
        return "Programare Info:\n" +
                "  ID Programare: " + idProgramare + "\n" +
                "  ID Clinica: " + idClinica + "\n" +
                "  ID Client: " + idClient + "\n" +
                "  ID Medic: " + idMedic + "\n" +
                "  Data Programare: " + sdf.format(dataProgramare) + "\n" +
                "  Cerinte Speciale: " + cerinteSpeciale + "\n" +
                "  ID Specializare: " + idSpecializare + "\n";
    }
}

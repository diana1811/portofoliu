package com.example.programari_medic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.programari_medic.Specializare;

import java.util.List;

@Dao
public interface SpecializareDAO {

    @Insert
    void insertSpecializare(Specializare specializare);

    @Query("SELECT * FROM specializari")
    List<Specializare> getAllSpecializari();

    @Delete
    void deleteSpecializare(Specializare specializare);
    @Query("DELETE FROM specializari WHERE idSpecializare = :idSpecializare")
    void deleteSpecializareById(int idSpecializare);
    @Update
    void updateSpecializare(Specializare specializare);
    @Query("UPDATE specializari SET descriere = :descriere WHERE idSpecializare = :idSpecializare")
    void updateDescriereSpecializare(int idSpecializare, String descriere);
    @Query("SELECT * FROM specializari WHERE denumire = :denumire LIMIT 1")
    Specializare getSpecializareByNume(String denumire);
}

package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class VeziServicii extends AppCompatActivity {

    private EditText etDenumire;
    private EditText etPret;
    private Button btnGolireDate;
    private FloatingActionButton fabSave;
    private FloatingActionButton fabDelete;
    private ListView lvServicii;
    private List<ServiciiExtra> serviciiExtra = new ArrayList<>();
    private FirebaseServiciiExtra firebaseService;
    private int indexServiciuSelectat = -1;
    Button btnInap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vezi_servicii);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initComponente();
        firebaseService = FirebaseServiciiExtra.getInstance();
        firebaseService.addServiciuListener(dataChangeCallback());
    }

    private Callback<List<ServiciiExtra>> dataChangeCallback() {
        return rezultat -> {
            serviciiExtra.clear();
            serviciiExtra.addAll(rezultat);
            ArrayAdapter<ServiciiExtra> adapter = (ArrayAdapter<ServiciiExtra>) lvServicii.getAdapter();
            adapter.notifyDataSetChanged();
            golireText();
        };
    }

    private void initComponente() {
        etDenumire = findViewById(R.id.etDenum);
        etPret = findViewById(R.id.etPr);
        btnGolireDate = findViewById(R.id.btnGolire);
        fabSave = findViewById(R.id.fabSv);
        fabDelete = findViewById(R.id.fabDel);
        lvServicii = findViewById(R.id.lvServicii);
            ArrayAdapter<ServiciiExtra> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, serviciiExtra);
        lvServicii.setAdapter(adapter);
        btnGolireDate.setOnClickListener(golireDateEventListener());
        fabSave.setOnClickListener(saveEventListener());
        fabDelete.setOnClickListener(deleteEventListener());
        lvServicii.setOnItemClickListener(serviciuSelectatEventListener());
        btnInap=findViewById(R.id.btnInap);
        btnInap.setOnClickListener(view->{
            Intent intent = new Intent(getApplicationContext(), Administrator.class);
            startActivity(intent);
        });
    }

    private AdapterView.OnItemClickListener serviciuSelectatEventListener() {
        return (adapterView, view, position, param) -> {
            indexServiciuSelectat = position;
            ServiciiExtra serviciiExtra1 = serviciiExtra.get(position);
            etDenumire.setText(serviciiExtra1.getDenumire());
            etPret.setText(String.valueOf(serviciiExtra1.getPret()));
        };
    }

    private View.OnClickListener deleteEventListener() {
        return view -> {
            if (indexServiciuSelectat != -1) {
                firebaseService.delete(serviciiExtra.get(indexServiciuSelectat));
            }
        };
    }

    private View.OnClickListener saveEventListener() {
        return view -> {
            if (validare()) {
                if (indexServiciuSelectat == -1) {
                    ServiciiExtra serviciu = actualizareServiciuFromUI(null);
                    firebaseService.insert(serviciu);
                } else {
                    ServiciiExtra serviciu = actualizareServiciuFromUI(serviciiExtra.get(indexServiciuSelectat).getId());
                    firebaseService.update(serviciu);
                }
            }

        };
    }

    private ServiciiExtra actualizareServiciuFromUI(String id) {
        ServiciiExtra serviciu = new ServiciiExtra();
        serviciu.setId(id);
        serviciu.setDenumire(etDenumire.getText().toString());
        serviciu.setPret(Float.valueOf(etPret.getText().toString()));
        return serviciu;
    }

    private boolean validare() {
        if (etDenumire.getText() == null || etDenumire.getText().toString().isEmpty() || etPret.getText() == null || etPret.getText().toString().isEmpty()) {
            Toast.makeText(this, "Validarea nu a functionat", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private View.OnClickListener golireDateEventListener() {
        return view -> golireText();
    }

    private void golireText() {
        etDenumire.setText(null);
        etPret.setText(null);
        indexServiciuSelectat = -1;
    }
}
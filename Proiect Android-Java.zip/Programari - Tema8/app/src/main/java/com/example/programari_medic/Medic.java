package com.example.programari_medic;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.io.Serializable;
@Entity(  tableName = "medici",foreignKeys ={ @ForeignKey(
        entity = Clinica.class,
        parentColumns = "idClinica",
        childColumns = "idClinica",
        onDelete = ForeignKey.CASCADE),
        @ForeignKey(
        entity = Specializare.class,
        parentColumns = "idSpecializare",
        childColumns = "idSpecializare",
        onDelete = ForeignKey.CASCADE
)})
public class Medic implements Serializable {
    @PrimaryKey(autoGenerate = true)
    int idMedic;
    int idClinica;
    int idSpecializare;
    String nume;
    int aniExperienta;


    public Medic( int idClinica, int idSpecializare, String nume, int aniExperienta) {

        this.idClinica = idClinica;
        this.idSpecializare = idSpecializare;
        this.nume = nume;
        this.aniExperienta = aniExperienta;

    }

    public void setIdMedic(int idMedic) {
        this.idMedic = idMedic;
    }

    public int getIdMedic() {
        return idMedic;
    }

    public int getIdClinica() {
        return idClinica;
    }

    public int getIdSpecializare() {
        return idSpecializare;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getAniExperienta() {
        return aniExperienta;
    }

    public void setAniExperienta(int aniExperienta) {
        this.aniExperienta = aniExperienta;
    }

    @Override
    public String toString() {
        return  nume;
    }


//    @Override
//    public String toString() {
//        return "Medic{" +
//                "idMedic=" + idMedic +
//                ", idClinica=" + idClinica +
//                ", idSpecializare=" + idSpecializare +
//                ", nume='" + nume + '\'' +
//                ", aniExperienta=" + aniExperienta +
//                '}';
//    }
}

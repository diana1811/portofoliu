package com.example.programari_medic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.programari_medic.Sugestie;

import java.util.List;

@Dao
public interface SugestieDAO {

    @Insert
    void insertSugestie(Sugestie sugestie);

    @Query("SELECT * FROM sugestii")
    List<Sugestie> getAllSugestii();

    @Delete
    void deleteSugestie(Sugestie sugestie);
    @Update
    void updateSugestie(Sugestie sugestie);
}

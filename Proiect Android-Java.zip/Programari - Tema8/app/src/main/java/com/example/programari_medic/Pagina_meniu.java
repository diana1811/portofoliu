package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Pagina_meniu extends AppCompatActivity {
    Button btnProgramari;
    Button btnContulMeu;
    Button btnIstoric;
    Button btnRapoarte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_pagina_meniu);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnProgramari=findViewById(R.id.btnProgramari);
        btnIstoric=findViewById(R.id.btnIstoric);
        btnContulMeu=findViewById(R.id.btnContulMeu);
        btnRapoarte=findViewById(R.id.btnRapoarte);
        btnIstoric.setOnClickListener(view->{
            Toast.makeText(this, "Aceasta pagina nu a fost inca realizata", Toast.LENGTH_LONG).show();
        });
        btnContulMeu.setOnClickListener(view->{
            Toast.makeText(this, "Aceasta pagina nu a fost inca realizata", Toast.LENGTH_LONG).show();
        });
        btnRapoarte.setOnClickListener(view->{
            Toast.makeText(this, "Aceasta pagina nu a fost inca realizata", Toast.LENGTH_LONG).show();
        });
        btnProgramari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Pagina_meniu.this, Programari.class);
                startActivity(intent);
            }
        });


    }


}
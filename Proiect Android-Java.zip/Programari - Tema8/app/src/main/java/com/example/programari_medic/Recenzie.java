package com.example.programari_medic;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import com.example.programari_medic.Programari;
@Entity(  tableName = "recenzii",  foreignKeys = {@ForeignKey(
        entity = Clinica.class,
        parentColumns = "idClinica",
        childColumns = "idClinica",
        onDelete = ForeignKey.CASCADE
), @ForeignKey(
        entity = Client.class,
        parentColumns = "idClient",
        childColumns = "idClient",
        onDelete = ForeignKey.CASCADE
)})
public class Recenzie {
    @PrimaryKey(autoGenerate = true)
    int idRecenzie;
    String recenzie;
    int idClinica;
    int idClient;

    public Recenzie(String recenzie, int idClinica, int idClient) {

        this.recenzie = recenzie;
        this.idClinica = idClinica;
        this.idClient = idClient;
    }

    public int getIdRecenzie() {
        return idRecenzie;
    }



    public String getRecenzie() {
        return recenzie;
    }

    public void setRecenzie(String recenzie) {
        this.recenzie = recenzie;
    }

    public int getIdClinica() {
        return idClinica;
    }

    public void setIdClinica(int idClinica) {
        this.idClinica = idClinica;
    }

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    @Override
    public String toString() {
        return "Recenzie{" +
                "idRecenzie=" + idRecenzie +
                ", recenzie='" + recenzie + '\'' +
                ", idClinica=" + idClinica +
                ", idClient=" + idClient +
                '}';
    }
}

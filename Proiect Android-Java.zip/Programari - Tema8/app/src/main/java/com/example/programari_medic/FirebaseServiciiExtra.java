package com.example.programari_medic;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FirebaseServiciiExtra {

    private final DatabaseReference reference;
    private static FirebaseServiciiExtra firebaseService;

    private FirebaseServiciiExtra() {
        reference = FirebaseDatabase.getInstance().getReference("servicii_extra");
    }

    public static FirebaseServiciiExtra getInstance() {
        if (firebaseService == null) {
            synchronized (FirebaseService.class) {
                if (firebaseService == null) {
                    firebaseService = new FirebaseServiciiExtra();
                }
            }
        }
        return firebaseService;
    }

    public void insert(ServiciiExtra serviciiExtra) {
        if (serviciiExtra == null || serviciiExtra.getId() != null) {
            return;
        }
        String id = reference.push().getKey();
        serviciiExtra.setId(id);
        reference.child(serviciiExtra.getId()).setValue(serviciiExtra);
    }

    public void update(ServiciiExtra serviciiExtra) {
        if (serviciiExtra == null || serviciiExtra.getId() == null) {
            return;
        }
        reference.child(serviciiExtra.getId()).setValue(serviciiExtra);
    }

    public void delete(ServiciiExtra serviciiExtra) {
        if (serviciiExtra == null || serviciiExtra.getId() == null) {
            return;
        }
        reference.child(serviciiExtra.getId()).removeValue();
    }

    public void addServiciuListener(Callback<List<ServiciiExtra>> callback) {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<ServiciiExtra> servicii = new ArrayList<>();
                for (DataSnapshot data : snapshot.getChildren()) {
                    ServiciiExtra serviciu = data.getValue(ServiciiExtra.class);
                    if (serviciu != null) {
                        servicii.add(serviciu);
                    }
                }
                callback.runOnUI(servicii);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("firebase", "Serviciul nu este accesibil!");
            }
        });
    }

}

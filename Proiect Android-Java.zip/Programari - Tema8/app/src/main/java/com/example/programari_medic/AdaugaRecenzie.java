package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class AdaugaRecenzie extends AppCompatActivity {
    Button btnAdaugaRecenzie;
    EditText etAdaugaRecenzie;
    Button btnBackR;
    Spinner spClientRec;
    Spinner spClinicaRec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adauga_recenzie);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnAdaugaRecenzie = findViewById(R.id.btnTrimiteRecenzie);
        etAdaugaRecenzie = findViewById(R.id.etAddRecenzie);
        btnBackR = findViewById(R.id.btnBackR);
        spClientRec = findViewById(R.id.spinnerClient);
        spClinicaRec = findViewById(R.id.spinnerClinica);

        ProgramariDB dbInstance = ProgramariDB.getInstance(getApplicationContext());

        List<Client> clienti = dbInstance.getClientDAO().getAllClienti();
        ArrayAdapter<Client> adapterClienti = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, clienti);
        spClientRec.setAdapter(adapterClienti);

        List<Clinica> clinici = dbInstance.getClinicaDAO().getAllClinici();
        ArrayAdapter<Clinica> adapterClinici = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, clinici);
        spClinicaRec.setAdapter(adapterClinici);

        btnAdaugaRecenzie.setOnClickListener(view -> {
            String text = etAdaugaRecenzie.getText().toString();
            Client client = (Client) spClientRec.getSelectedItem();
            Clinica clinica = (Clinica) spClinicaRec.getSelectedItem();

            Recenzie recenzie = new Recenzie(text, clinica.getIdClinica(), client.getIdClient());
            dbInstance.getRecenzieDAO().insertRecenzie(recenzie);

            Toast.makeText(this, "Recenzie adăugată cu succes!", Toast.LENGTH_LONG).show();
        });

        btnBackR.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });
    }
}

package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Programari extends AppCompatActivity {

    Button btnProg;
    EditText etData;
    EditText etCerinte;
    Spinner spSpecializare;
    Spinner spMedic;
    Spinner spClinica;

    Button btnBackP;

    ProgramariDB dbInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_programari);

        etCerinte = findViewById(R.id.etCerinte);
        etData = findViewById(R.id.etDataProgramare);
        btnProg = findViewById(R.id.btnProg);
        spSpecializare = findViewById(R.id.spSpecializare);
        spMedic = findViewById(R.id.spMedic);
        spClinica = findViewById(R.id.spClinica);
        btnBackP = findViewById(R.id.btnBackP);

        dbInstance = ProgramariDB.getInstance(getApplicationContext());


        loadData();

        btnProg.setOnClickListener(view -> {
            String cerinte = etCerinte.getText().toString();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date data = null;
            try {
                data = sdf.parse(etData.getText().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            Clinica clinica = (Clinica) spClinica.getSelectedItem();
            Medic medic = (Medic) spMedic.getSelectedItem();
            Specializare specializare = (Specializare) spSpecializare.getSelectedItem();

            //Programare programare = new Programare(clinica.getIdClinica(), medic.getIdMedic(), data, cerinte, specializare.getIdSpecializare());

            //new Thread(() -> dbInstance.getProgramareDAO().insertProgramare(programare)).start();

            Toast.makeText(this, "Programare adăugată cu succes", Toast.LENGTH_LONG).show();
        });

        btnBackP.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Pagina_meniu.class);
            startActivity(intent);
        });
    }

    private void loadData() {

        List<Clinica> clinici = dbInstance.getClinicaDAO().getAllClinici();
        List<Medic> medici = dbInstance.getMedicDAO().getAllMedici();
        List<Specializare> specializari = dbInstance.getSpecializareDAO().getAllSpecializari();

        ArrayAdapter<Clinica> clinicaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, clinici);
        spClinica.setAdapter(clinicaAdapter);

        ArrayAdapter<Medic> medicAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, medici);
        spMedic.setAdapter(medicAdapter);

        ArrayAdapter<Specializare> specializareAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, specializari);
        spSpecializare.setAdapter(specializareAdapter);
    }
}
package com.example.programari_medic;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.nio.file.SecureDirectoryStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Entity(  tableName = "clinici")
public class Clinica implements Serializable {
    @PrimaryKey(autoGenerate = true)
    int idClinica;
    String denumire;
    int aniExistenta;
    Date dataInfiintare;


    public Clinica(String denumire, int aniExistenta, Date dataInfiintare) {
        this.denumire = denumire;
        this.aniExistenta = aniExistenta;
        this.dataInfiintare = dataInfiintare;

    }

    public int getIdClinica() {
        return idClinica;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public int getAniExistenta() {
        return aniExistenta;
    }

    public void setAniExistenta(int aniExistenta) {
        this.aniExistenta = aniExistenta;
    }

    public Date getDataInfiintare() {
        return dataInfiintare;
    }

    public void setDataInfiintare(Date dataInfiintare) {
        this.dataInfiintare = dataInfiintare;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Clinica clinica = (Clinica) o;
        return denumire.equals(clinica.denumire);
    }

    @Override
    public String toString() {
        return denumire;
    }

  //  @Override
//    public String toString() {
//        return "Clinica{" +
//                "denumire='" + denumire + '\'' +
//                ", aniExistenta=" + aniExistenta +
//                ", dataInfiintare=" + dataInfiintare +
//                ", specializari disponibile" +specializariDisponibile.toString()+
//
//                '}';
//    }
}

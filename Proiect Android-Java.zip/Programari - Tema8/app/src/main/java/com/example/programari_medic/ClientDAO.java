package com.example.programari_medic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.programari_medic.Client;

import java.util.List;

@Dao
public interface ClientDAO {

    @Insert
    void insertClient(Client client);

    @Query("SELECT * FROM clienti")
    List<Client> getAllClienti();

    @Delete
    void deleteClient(Client client);
    @Update
    void updateClient(Client client);
    @Query("SELECT * FROM clienti WHERE nume = :nume LIMIT 1")
    Client getClientByNume(String nume);

    @Query("SELECT * FROM clienti WHERE nume = :nume AND prenume = :prenume AND telefon = :telefon")
    Client getClient(String nume, String prenume, String telefon);
}
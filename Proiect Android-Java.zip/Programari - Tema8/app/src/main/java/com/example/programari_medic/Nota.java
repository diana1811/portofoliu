package com.example.programari_medic;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import com.example.programari_medic.Programari;
@Entity(  tableName = "note",  foreignKeys = {@ForeignKey(
        entity = Medic.class,
        parentColumns = "idMedic",
        childColumns = "idMedic",
        onDelete = ForeignKey.CASCADE
), @ForeignKey(
        entity = Client.class,
        parentColumns = "idClient",
        childColumns = "idClient",
        onDelete = ForeignKey.CASCADE
)})
public class Nota {
    @PrimaryKey(autoGenerate = true)
    int idNota;
    int nota;
    int idMedic;
    int idClient;

    public Nota(int nota, int idMedic, int idClient) {

        this.nota = nota;
        this.idMedic = idMedic;
        this.idClient = idClient;
    }

    public int getIdNota() {
        return idNota;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    public int getIdMedic() {
        return idMedic;
    }

    public void setIdMedic(int idMedic) {
        this.idMedic = idMedic;
    }

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    @Override
    public String toString() {
        return "Nota{" +
                "idNota=" + idNota +
                ", nota=" + nota +
                ", idMedic=" + idMedic +
                ", idClient=" + idClient +
                '}';
    }
}

package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Administrator extends AppCompatActivity {

    Button btnVMedici;
    Button btnVClienti;
    Button btnAddClinici;
    Button btnAddSpecializari;
    Button btnServiciisiProduse;
    Button btnServicii;
    Button btnBackToMain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_administrator);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnVMedici=findViewById(R.id.btnVMedici);
        btnVClienti=findViewById(R.id.btnVClienti);
        btnServiciisiProduse=findViewById(R.id.btnProduseSiServicii);
        btnServicii=findViewById(R.id.btnServicii);
        btnAddClinici=findViewById(R.id.btnAddClinici);
        btnAddSpecializari=findViewById(R.id.btnAddSpecializari);
        btnBackToMain=findViewById(R.id.btnBackToMain);
        btnVClienti.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), VeziClienti.class);
            startActivity(intent);
        });
        btnAddSpecializari.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), VeziSpecializari.class);
            startActivity(intent);
        });
        btnAddClinici.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), VeziClinici.class);
            startActivity(intent);
        });
        btnVMedici.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), VeziMedici.class);
            startActivity(intent);
        });
        btnServiciisiProduse.setOnClickListener(view->{
            Intent intent = new Intent(getApplicationContext(), ServSiProduse.class);
            startActivity(intent);
        });
        btnServicii.setOnClickListener(view->{
            Intent intent = new Intent(getApplicationContext(), VeziServicii.class);
            startActivity(intent);
        });
        btnBackToMain.setOnClickListener(view->{
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });

    }
}
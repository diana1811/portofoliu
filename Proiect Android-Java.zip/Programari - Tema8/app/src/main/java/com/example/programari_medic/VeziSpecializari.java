package com.example.programari_medic;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class VeziSpecializari extends AppCompatActivity {

    private ListView lvSpecializari;
    private Button btnAdaugaSp;
    private Button backSpecializare;
    private ProgramariDB dbInstance;
    private List<Specializare> specializari = new ArrayList<>();
    private TextView tvUltimaSpecializare;
    private ActivityResultLauncher<Intent> launcher;
    private static final String[] urls = {"https://www.jsonkeeper.com/b/OEV4", "https://www.jsonkeeper.com/b/JGX2"};


    private void incarcareSpecializariDinRetea(){
        Thread thread=new Thread(){
            @Override
            public void run() {
                for(String url:urls) {
                    HttpsManager httpsManager = new HttpsManager(url);
                    String json = httpsManager.procesare();
                    new Handler(getMainLooper()).post(() -> {
                        try {
                            parsareDinHttps(json);
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
            }
        };
        thread.start();
    }
    private void parsareDinHttps(String json) throws JSONException {
        List<Specializare> parsedSpecializari = SpecializariParser.specializariParser(json);
        for (Specializare specializare : parsedSpecializari) {
            if (dbInstance.getSpecializareDAO().getSpecializareByNume(specializare.getDenumire()) == null) {
                dbInstance.getSpecializareDAO().insertSpecializare(specializare);
            }
        }

        runOnUiThread(() -> {
            specializari.clear();
            specializari.addAll(dbInstance.getSpecializareDAO().getAllSpecializari());
            SpecializareAdapter adapter = new SpecializareAdapter(this, R.layout.view_specializari, specializari, getLayoutInflater());
            lvSpecializari.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vezi_specializari);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lvSpecializari = findViewById(R.id.lvSpecializari);
        btnAdaugaSp = findViewById(R.id.btnAdaugaSpecializare);
        backSpecializare = findViewById(R.id.btnBackSp);
        tvUltimaSpecializare = findViewById(R.id.tvUltimaSpecializare);
        incarcareSpecializariDinRetea();
        dbInstance = ProgramariDB.getInstance(getApplicationContext());
        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadSpecializari();
                    }
                });

        loadSpecializari();

        lvSpecializari.setOnItemClickListener((adapterView, view, position, l) -> {
            Specializare specializare = specializari.get(position);
            specializari.remove(position);
            dbInstance.getSpecializareDAO().deleteSpecializareById(specializare.getIdSpecializare());
            SpecializareAdapter adapter= (SpecializareAdapter) lvSpecializari.getAdapter();
            adapter.notifyDataSetChanged();
        });

        lvSpecializari.setOnItemLongClickListener((parent, view, position, id) -> {
            Specializare specializare = specializari.get(position);
            Intent intent = new Intent(VeziSpecializari.this, AdaugaSpecializare.class);
            intent.putExtra("edit", specializare);
            launcher.launch(intent);
            return true;
        });


        btnAdaugaSp.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), AdaugaSpecializare.class);
            launcher.launch(intent);
        });

        backSpecializare.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Administrator.class);
            startActivity(intent);
        });

        SharedPreferences sharedPreferences = getSharedPreferences("local", MODE_PRIVATE);
        String ultimaSpecializare = sharedPreferences.getString("ultimaSpecializare", "Nu există nicio specializare adăugată.");
        tvUltimaSpecializare.setText("Ultima specializare adăugată: " + ultimaSpecializare);
    }

    private void loadSpecializari() {

            List<Specializare> newSpecializari = dbInstance.getSpecializareDAO().getAllSpecializari();

            if (newSpecializari.isEmpty()) {
                Toast.makeText(VeziSpecializari.this, "Nu sunt specializări în baza de date!", Toast.LENGTH_SHORT).show();
            } else {
                specializari.clear();
                specializari.addAll(newSpecializari);
                SpecializareAdapter adapter = new SpecializareAdapter(this, R.layout.view_specializari, specializari, getLayoutInflater());
                lvSpecializari.setAdapter(adapter);
            }

    }


}
package com.example.programari_medic;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class VeziMedici extends AppCompatActivity {

    private ListView lvMedici;
    private Button btnAdd;
    private Button backMedici;
    private ProgramariDB dbInstance;
    private List<Medic> medici = new ArrayList<>();
    private ActivityResultLauncher<Intent> launcher;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vezi_medici);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lvMedici = findViewById(R.id.lvMedici);
        btnAdd = findViewById(R.id.btnaddmedici);
        backMedici = findViewById(R.id.btnBackMe);
        textView = findViewById(R.id.textView);
        SharedPreferences sharedPreferences = getSharedPreferences("medic_preferences", MODE_PRIVATE);
        String savedText = sharedPreferences.getString("medicText", "Nu există text salvat.");
        textView.setText(savedText);
        dbInstance = ProgramariDB.getInstance(getApplicationContext());
        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadMedici();
                    }
                });

        loadMedici();

        lvMedici.setOnItemClickListener((adapterView, view, position, l) -> {
            Medic medic = medici.get(position);
            medici.remove(medic);
            dbInstance.getMedicDAO().deleteMedicById(medic.getIdMedic());
            MedicAdapter adapter= (MedicAdapter) lvMedici.getAdapter();
            adapter.notifyDataSetChanged();
        });

        lvMedici.setOnItemLongClickListener((parent, view, position, id) -> {
            Medic medic = medici.get(position);
            Intent intent = new Intent(VeziMedici.this, AdaugaMedici.class);
            intent.putExtra("editMedic", medic);
            launcher.launch(intent);
            return true;
        });

        btnAdd.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), AdaugaMedici.class);
            launcher.launch(intent);
        });
        backMedici.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Administrator.class);
            startActivity(intent);
        });
    }


    private void loadMedici() {
        medici = dbInstance.getMedicDAO().getAllMedici();

        if (medici.isEmpty()) {
            Toast.makeText(VeziMedici.this, "Nu sunt medici în baza de date!", Toast.LENGTH_SHORT).show();
        } else {
            MedicAdapter adapter = new MedicAdapter(this, R.layout.view_medici, medici, getLayoutInflater());
            lvMedici.setAdapter(adapter);
        }
    }


}

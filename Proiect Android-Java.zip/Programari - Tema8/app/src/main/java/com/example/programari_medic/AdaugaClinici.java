package com.example.programari_medic;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AdaugaClinici extends AppCompatActivity {

    EditText etDenumire;
    EditText etDataInfiintare;
    EditText etAni;
    Spinner spnspecializari;
    Button btnAddSp;
    Button btnAddClinica;
    List<Specializare> specializari = new ArrayList<>();
    ProgramariDB dbInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adauga_clinici);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etDenumire = findViewById(R.id.etden);
        etDataInfiintare = findViewById(R.id.etdatainfiintare);
        etAni = findViewById(R.id.etani);
        spnspecializari = findViewById(R.id.spinnerSp);
        btnAddSp = findViewById(R.id.btnadSpToClinica);
        btnAddClinica = findViewById(R.id.btnAddClinica);

        dbInstance = ProgramariDB.getInstance(getApplicationContext());

        loadSpecializari();

        btnAddSp.setOnClickListener(view -> {
            Specializare specializareSelectata = (Specializare) spnspecializari.getSelectedItem();
            if (specializareSelectata != null) {
                specializari.add(specializareSelectata);
                Toast.makeText(this, specializareSelectata.toString() + " adăugată!", Toast.LENGTH_SHORT).show();
            }
        });

        btnAddClinica.setOnClickListener(view -> {
            String denumire = etDenumire.getText().toString();
            int ani = Integer.parseInt(etAni.getText().toString());
            Date dataPreluata;

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            try {
                dataPreluata = sdf.parse(etDataInfiintare.getText().toString());
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }

            Clinica clinica = new Clinica(denumire, ani, dataPreluata);
            dbInstance.getClinicaDAO().insertClinica(clinica);

            for (Specializare sp : specializari) {
                dbInstance.getSpecializareDAO().insertSpecializare(sp);
            }
            SharedPreferences sharedPreferences=getSharedPreferences("local2",MODE_PRIVATE);
            String token=sharedPreferences.getString("clinica", "valoare_default");
            Toast.makeText(getApplicationContext(), token, Toast.LENGTH_SHORT).show();

            Intent intent = getIntent();
            intent.putExtra("clinicaFromIntent", clinica);
            setResult(RESULT_OK, intent);
            finish();
        });
    }

    private void loadSpecializari() {
        List<Specializare> specializariDinDB = dbInstance.getSpecializareDAO().getAllSpecializari();

        if (specializariDinDB.isEmpty()) {
            Toast.makeText(this, "Nu există specializări în baza de date!", Toast.LENGTH_SHORT).show();
        } else {
            ArrayAdapter<Specializare> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, specializariDinDB);
            spnspecializari.setAdapter(adapter);
        }
    }
}

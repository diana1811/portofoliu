package com.example.programari_medic;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ClientiParser {
    private static final String NUME="nume";
    private static final String PRENUME="prenume";
    private static final String TELEFON="telefon";
    private static final String LOCALITATE="localitate";
    private static final String DATA_NASTERE="dataNastere";
    public static List<Client> clientiParser(String json) throws JSONException, ParseException {
        List<Client> lista = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(json);
            lista.addAll(listaParser(jsonArray));
        } catch (JSONException | ParseException e) {
            JSONObject jsonObject = new JSONObject(json);
            lista.add(clientParser(jsonObject));
        }
        return lista;
    }
    private static List<Client> listaParser(JSONArray jsonArray) throws JSONException, ParseException {
        List<Client> lista=new ArrayList<>();
        for(int i=0;i< jsonArray.length();i++){
            lista.add(clientParser(jsonArray.getJSONObject(i)));
        }
        return lista;
    }
    private static Client clientParser(JSONObject jsonObject) throws JSONException, ParseException {
        String nume= jsonObject.getString(NUME);
        String prenume= jsonObject.getString(PRENUME);
        String localitate= jsonObject.getString(LOCALITATE);
        String telefon= jsonObject.getString(TELEFON);
        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
        Date dataNastere= sdf.parse(jsonObject.getString(DATA_NASTERE));
        Client client=new Client(nume, dataNastere,localitate, telefon,prenume);
        return client;
    }
}

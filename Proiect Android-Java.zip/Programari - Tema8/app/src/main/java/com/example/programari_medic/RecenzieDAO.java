package com.example.programari_medic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.programari_medic.Recenzie;

import java.util.List;

@Dao
public interface RecenzieDAO {

    @Insert
    void insertRecenzie(Recenzie recenzie);

    @Query("SELECT * FROM recenzii")
    List<Recenzie> getAllRecenzii();

    @Delete
    void deleteRecenzie(Recenzie recenzie);
    @Update
    void updateRecenzie(Recenzie recenzie);
}
package com.example.programari_medic;

public interface CallbackServicii <R> {
    void runOnUI(R rezultat);
}

package com.example.programari_medic;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONException;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class VeziClinici extends AppCompatActivity {

    private ListView lvClinici;
    private Button btnadd;
    private Button backClinici;
    private ProgramariDB dbInstance;
    private List<Clinica> clinici = new ArrayList<>();
    private ActivityResultLauncher<Intent> launcher;
    private static final String[] urls = {"https://www.jsonkeeper.com/b/P3QP", "https://www.jsonkeeper.com/b/KCA8"};


    private void incarcareMediciDinRetea(){
        Thread thread=new Thread(){
            @Override
            public void run() {
                for(String url:urls) {
                    HttpsManager httpsManager = new HttpsManager(url);
                    String json = httpsManager.procesare();
                    new Handler(getMainLooper()).post(() -> {
                        try {
                            parsareDinHttps(json);
                        } catch (JSONException | ParseException e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
            }
        };
        thread.start();
    }
    private void parsareDinHttps(String json) throws JSONException, ParseException {
        List<Clinica> parsedClinica = CliniciParser.cliniciParser(json);
        for (Clinica clinica : parsedClinica) {
            if (dbInstance.getClinicaDAO().getClinicaByNume(clinica.getDenumire()) == null) {
                dbInstance.getClinicaDAO().insertClinica(clinica);
            }
        }

        runOnUiThread(() -> {
            clinici.clear();
            clinici.addAll(dbInstance.getClinicaDAO().getAllClinici());
            CliniciAdapter adapter = new CliniciAdapter(this, R.layout.view_clinici, clinici, getLayoutInflater());
            lvClinici.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vezi_clinici);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lvClinici = findViewById(R.id.lvClinici);
        btnadd = findViewById(R.id.btnAdaugaClinica);
        backClinici = findViewById(R.id.btnBackCl);
        incarcareMediciDinRetea();
        dbInstance = ProgramariDB.getInstance(getApplicationContext());
        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadClinics();
                    }
                });

        loadClinics();

        btnadd.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), AdaugaClinici.class);
            launcher.launch(intent);
        });

        backClinici.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Administrator.class);
            startActivity(intent);
        });

        SharedPreferences sharedPreferences = getSharedPreferences("local2", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("clinica", "clinica adaugata cu succes");
        editor.apply();
    }

    private void loadClinics() {
        List<Clinica> newClinici = dbInstance.getClinicaDAO().getAllClinici();

        if (newClinici.isEmpty()) {
            Toast.makeText(VeziClinici.this, "Nu sunt clinici în baza de date!", Toast.LENGTH_SHORT).show();
        } else {
            clinici.clear();
            clinici.addAll(newClinici);
            CliniciAdapter adapter = new CliniciAdapter(this, R.layout.view_clinici, clinici, getLayoutInflater());
            lvClinici.setAdapter(adapter);
        }
    }


}

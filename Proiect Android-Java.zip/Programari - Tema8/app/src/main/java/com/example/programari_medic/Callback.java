package com.example.programari_medic;


public interface Callback<R> {
    void runOnUI(R rezultat);
}
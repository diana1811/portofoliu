package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class AdaugaSugestii extends AppCompatActivity {
    Button btnAdaugaSugestie;
    EditText etAdaugaSugestie;
    Button btnBackS;
    Spinner spClienti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adauga_sugestii);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnAdaugaSugestie = findViewById(R.id.btnTrimiteSugestie);
        etAdaugaSugestie = findViewById(R.id.etAddSugestie);
        btnBackS = findViewById(R.id.btnBackS);
        spClienti = findViewById(R.id.spinnerClienti);

        ProgramariDB dbInstance = ProgramariDB.getInstance(getApplicationContext());

        List<Client> clienti = dbInstance.getClientDAO().getAllClienti();
        ArrayAdapter<Client> adapterClienti = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, clienti);
        spClienti.setAdapter(adapterClienti);

        btnAdaugaSugestie.setOnClickListener(view -> {
            String text = etAdaugaSugestie.getText().toString();
            Client client = (Client) spClienti.getSelectedItem();

            Sugestie sugestie = new Sugestie(client.getIdClient(), text);
            dbInstance.getSugestieDAO().insertSugestie(sugestie);

            Toast.makeText(this, "Sugestie adăugată cu succes!", Toast.LENGTH_LONG).show();
        });

        btnBackS.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        });
    }
}

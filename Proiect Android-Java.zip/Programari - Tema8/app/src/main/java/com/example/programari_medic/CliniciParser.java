package com.example.programari_medic;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CliniciParser {
    private static final String DENUMIRE="denumire";
    private static final String ANI_EXISTENTA="ani_existenta";
    private static final String DATA_INFIINTARE="dataInfiintare";

    public static List<Clinica> cliniciParser(String json) throws JSONException, ParseException {
        List<Clinica> lista = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(json);
            lista.addAll(listaParser(jsonArray));
        } catch (JSONException e) {
            JSONObject jsonObject = new JSONObject(json);
            lista.add(clinicaParser(jsonObject));
        }
        return lista;
    }
    private static List<Clinica> listaParser(JSONArray jsonArray) throws JSONException, ParseException {
        List<Clinica> lista=new ArrayList<>();
        for(int i=0;i< jsonArray.length();i++){
            lista.add(clinicaParser(jsonArray.getJSONObject(i)));
        }
        return lista;
    }
    private static Clinica clinicaParser(JSONObject jsonObject) throws JSONException, ParseException {
        String denumire= jsonObject.getString(DENUMIRE);
        int ani= jsonObject.getInt(ANI_EXISTENTA);
        SimpleDateFormat  sdf=new SimpleDateFormat("dd/MM/yyyy");
        Date data_infiintare= sdf.parse(jsonObject.getString(DATA_INFIINTARE));
        Clinica clinica=new Clinica(denumire,ani,data_infiintare);
        return clinica;
    }
}

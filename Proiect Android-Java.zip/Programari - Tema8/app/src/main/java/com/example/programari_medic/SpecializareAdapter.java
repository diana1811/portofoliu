package com.example.programari_medic;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.List;

public class SpecializareAdapter extends ArrayAdapter<Specializare> {
    private Context context;
    private List<Specializare> specializareList;
    private int layoutId;
    private LayoutInflater inflater;
    public SpecializareAdapter(@NonNull Context context, int resource, @NonNull List<Specializare> objects, LayoutInflater inflater) {
        super(context, resource, objects);
        this.context=context;
        this.layoutId=resource;
        this.specializareList=objects;
        this.inflater=inflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view=inflater.inflate(layoutId, parent,false);
        Specializare specializare=specializareList.get(position);
        TextView tvViewSpDen=view.findViewById(R.id.tvViewSpNume);
        TextView tvViewSpdescriere=view.findViewById(R.id.tvViewSpDescriere);
        tvViewSpDen.setText(specializare.getDenumire());
        tvViewSpdescriere.setText(specializare.getDescriere());
        if (specializare.getDescriere().length() > 50) {
            tvViewSpdescriere.setTextColor(Color.GREEN);
        } else {
            tvViewSpdescriere.setTextColor(Color.BLACK);
        }

        return view;
    }
}

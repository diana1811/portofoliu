package com.example.programari_medic;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
@Entity(  tableName = "specializari")
public class Specializare implements Serializable {
    @PrimaryKey(autoGenerate = true)
    int idSpecializare;
    String denumire;
    String descriere;

    public Specializare(String denumire, String descriere) {

        this.denumire = denumire;
        this.descriere = descriere;
    }

    public int getIdSpecializare() {
        return idSpecializare;
    }

    public void setIdSpecializare(int idSpecializare) {
        this.idSpecializare = idSpecializare;
    }

    public String getDenumire() {
        return denumire;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Specializare specializare = (Specializare) o;
        return denumire.equals(specializare.denumire);
    }

    @Override
    public String toString() {
        return denumire;
    }
//    @Override
//    public String toString() {
//        return "Specializare{" +
//                "denumire='" + denumire + '\'' +
//                ", descriere='" + descriere + '\'' +
//                '}';
//    }
}

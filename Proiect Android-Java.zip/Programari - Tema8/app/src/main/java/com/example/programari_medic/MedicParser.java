package com.example.programari_medic;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MedicParser {
    private static final String ID_CLINICA="idClinica";
    private static final String ID_SPECIALIZARE="idSpecializare";
    private static final String NUME="nume";
    private static final String ANI_EXPERIENTA="areExperienta";

    public static List<Medic> mediciParser(String json) throws JSONException {
        List<Medic> lista = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(json);
            lista.addAll(listaParser(jsonArray));
        } catch (JSONException e) {
            JSONObject jsonObject = new JSONObject(json);
            lista.add(medicParser(jsonObject));
        }
        return lista;
    }
    private static List<Medic> listaParser(JSONArray jsonArray) throws JSONException {
        List<Medic> lista=new ArrayList<>();
        for(int i=0;i< jsonArray.length();i++){
            lista.add(medicParser(jsonArray.getJSONObject(i)));
        }
        return lista;
    }
    private static Medic medicParser(JSONObject jsonObject) throws JSONException {
        int id_c= jsonObject.getInt(ID_CLINICA);
        int id_s= jsonObject.getInt(ID_SPECIALIZARE);
        String nume= jsonObject.getString(NUME);
        int aniExp= jsonObject.getInt(ANI_EXPERIENTA);
        Medic medic=new Medic(id_c,id_s,nume,aniExp);
        return medic;
    }
}

package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONException;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class VeziClienti extends AppCompatActivity {

    private ListView lvClienti;
    private Button backClienti;
    private Button btnAdaugaClient;
    private ProgramariDB dbInstance;
    private ActivityResultLauncher<Intent> launcher;
    List<Client> clienti=new ArrayList<>();
    private static final String[] urls = {"https://www.jsonkeeper.com/b/I1SY", "https://www.jsonkeeper.com/b/8ISK"};


    private void incarcareClientiDinRetea(){
        Thread thread=new Thread(){
            @Override
            public void run() {
                for(String url:urls) {
                    HttpsManager httpsManager = new HttpsManager(url);
                    String json = httpsManager.procesare();
                    new Handler(getMainLooper()).post(() -> {
                        try {
                            parsareDinHttps(json);
                        } catch (JSONException | ParseException e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
            }
        };
        thread.start();
    }
    private void parsareDinHttps(String json) throws JSONException, ParseException {
        List<Client> parsedClienti = ClientiParser.clientiParser(json);
        for (Client client : parsedClienti) {
            if (dbInstance.getClientDAO().getClientByNume(client.getNume()) == null) {
                dbInstance.getClientDAO().insertClient(client);
            }
        }

        runOnUiThread(() -> {
            clienti.clear();
            clienti.addAll(dbInstance.getClientDAO().getAllClienti());
            ArrayAdapter<Client> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, clienti);
            lvClienti.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vezi_clienti);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lvClienti = findViewById(R.id.lvClienti);
        backClienti = findViewById(R.id.btnBackClienti);
        btnAdaugaClient = findViewById(R.id.btna);
        incarcareClientiDinRetea();
        dbInstance = ProgramariDB.getInstance(getApplicationContext());

        launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadClienti();
                    }
                });

        loadClienti();

        btnAdaugaClient.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Inregistrare.class);
            launcher.launch(intent);
        });

        backClienti.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Administrator.class);
            startActivity(intent);
        });
    }

    private void loadClienti() {
        List<Client> newClienti = dbInstance.getClientDAO().getAllClienti();

        if (newClienti.isEmpty()) {
            Toast.makeText(VeziClienti.this, "Nu sunt clienti în baza de date!", Toast.LENGTH_SHORT).show();
        } else {
            clienti.clear();
            clienti.addAll(newClienti);
            ArrayAdapter<Client> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, clienti);
            lvClienti.setAdapter(adapter);
        }
    }
}

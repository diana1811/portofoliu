package com.example.programari_medic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.programari_medic.Clinica;

import java.util.List;

@Dao
public interface ClinicaDAO {

    @Insert
    void insertClinica(Clinica clinica);

    @Query("SELECT * FROM clinici")
    List<Clinica> getAllClinici();

    @Delete
    void deleteClinica(Clinica clinica);
    @Update
    void updateClinica(Clinica clinica);
    @Query("SELECT * FROM clinici WHERE denumire = :denumire LIMIT 1")
    Clinica getClinicaByNume(String denumire);
}
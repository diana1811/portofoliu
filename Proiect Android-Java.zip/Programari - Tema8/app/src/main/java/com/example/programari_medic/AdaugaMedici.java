package com.example.programari_medic;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class AdaugaMedici extends AppCompatActivity {

    Spinner spCl;
    Spinner spSp;
    EditText etnumedoc;
    EditText etaniexp;
    Button btnAddMedic;
    private boolean isEditing = false;
    EditText editText;
    Button btnSaveText;
    private ProgramariDB dbInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adauga_medici);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editText = findViewById(R.id.editText);
        btnSaveText = findViewById(R.id.btnSaveText);
        spCl = findViewById(R.id.spinnerCl);
        spSp = findViewById(R.id.spinnerSp);
        etnumedoc = findViewById(R.id.etnumedoc);
        etaniexp = findViewById(R.id.etAniExp);
        btnAddMedic = findViewById(R.id.btnAddMedic);

        dbInstance = ProgramariDB.getInstance(getApplicationContext());

        List<Clinica> clinici = dbInstance.getClinicaDAO().getAllClinici();
        List<Specializare> listaSpecializari = dbInstance.getSpecializareDAO().getAllSpecializari();

        ArrayAdapter<Clinica> adapterClinici = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, clinici);
        spCl.setAdapter(adapterClinici);

        ArrayAdapter<Specializare> adapterSpecializari = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, listaSpecializari);
        spSp.setAdapter(adapterSpecializari);

        Intent editIntent = getIntent();
        Medic existingMedic = (Medic) editIntent.getSerializableExtra("editMedic");
        if (editIntent.hasExtra("editMedic")) {
            isEditing = true;

            Medic medic = (Medic) editIntent.getSerializableExtra("editMedic");
            etnumedoc.setText(medic.getNume());
            etaniexp.setText(String.valueOf(medic.getAniExperienta()));

            ArrayAdapter<Clinica> editedAdapter = (ArrayAdapter<Clinica>) spCl.getAdapter();
            for (int i = 0; i < editedAdapter.getCount(); i++) {
                if (medic.getIdClinica() == editedAdapter.getItem(i).getIdClinica()) {
                    spCl.setSelection(i);
                    break;
                }
            }

            ArrayAdapter<Specializare> editedAdapterSp = (ArrayAdapter<Specializare>) spSp.getAdapter();
            for (int i = 0; i < editedAdapterSp.getCount(); i++) {
                if (medic.getIdSpecializare() == editedAdapterSp.getItem(i).getIdSpecializare()) {
                    spSp.setSelection(i);
                    break;
                }
            }
        }

        btnSaveText.setOnClickListener(v -> {
            String text = editText.getText().toString();
            SharedPreferences sharedPreferences = getSharedPreferences("medic_preferences", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("medicText", text);
            editor.apply();
            Toast.makeText(AdaugaMedici.this, "Text salvat!", Toast.LENGTH_SHORT).show();
        });

        btnAddMedic.setOnClickListener(view -> {
            String nume = etnumedoc.getText().toString();
            int ani = Integer.parseInt(etaniexp.getText().toString());

            Clinica clinica = (Clinica) spCl.getSelectedItem();
            int idClinica = clinica.getIdClinica();
            Specializare specializare = (Specializare) spSp.getSelectedItem();
            int idSpecializare = specializare.getIdSpecializare();

            Medic medic = new Medic(idClinica, idSpecializare, nume, ani);

            if (isEditing) {
                medic.setIdMedic(existingMedic.getIdMedic());
                dbInstance.getMedicDAO().updateMedic(medic);
                Toast.makeText(AdaugaMedici.this, "Medic actualizat cu succes!", Toast.LENGTH_SHORT).show();
            } else {
                dbInstance.getMedicDAO().insertMedic(medic);
                Toast.makeText(AdaugaMedici.this, "Medic adăugat cu succes!", Toast.LENGTH_SHORT).show();
            }


            Intent resultIntent = new Intent();
            resultIntent.putExtra("medicFromIntent", medic);
            isEditing=false;
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}

package com.example.programari_medic;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;


@Database(entities = {Client.class, Clinica.class, Medic.class, Nota.class, Programare.class,Recenzie.class, Specializare.class, Sugestie.class}, version = 6, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class ProgramariDB extends RoomDatabase {
    private static ProgramariDB instance;
    private static final String dbName = "programari.db";

    public static ProgramariDB getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context, ProgramariDB.class, dbName)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }


    public abstract ClientDAO getClientDAO();
    public abstract ClinicaDAO getClinicaDAO();
    public abstract MedicDAO getMedicDAO();
    public abstract NotaDAO getNotaDAO();
    public abstract ProgramareDAO getProgramareDAO();
    public abstract RecenzieDAO getRecenzieDAO();
    public abstract SpecializareDAO getSpecializareDAO();
    public abstract SugestieDAO getSugestieDAO();

}
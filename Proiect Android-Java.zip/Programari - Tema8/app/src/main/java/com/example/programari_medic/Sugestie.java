package com.example.programari_medic;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import com.example.programari_medic.Programari;

import java.io.Serializable;
@Entity(  tableName = "sugestii",  foreignKeys = @ForeignKey(
        entity = Client.class,
        parentColumns = "idClient",
        childColumns = "idClient",
        onDelete = ForeignKey.CASCADE
))
public class Sugestie implements Serializable {
    @PrimaryKey(autoGenerate = true)
    int idSugestie;
    int idClient;
    String sugestie;

    public Sugestie(int idClient, String sugestie) {
        this.idSugestie = idSugestie;
        this.idClient = idClient;
        this.sugestie = sugestie;
    }

    public int getIdSugestie() {
        return idSugestie;
    }

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    public String getSugestie() {
        return sugestie;
    }

    public void setSugestie(String sugestie) {
        this.sugestie = sugestie;
    }

    @Override
    public String toString() {
        return "Sugestie{" +
                "idSugestie=" + idSugestie +
                ", idClient=" + idClient +
                ", sugestie='" + sugestie + '\'' +
                '}';
    }
}

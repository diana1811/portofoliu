package com.example.programari_medic;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SpecializariParser {
    private static final String DENUMIRE="denumire";
    private static final String DESCRIERE="descriere";

    public static List<Specializare> specializariParser(String json) throws JSONException {
        List<Specializare> lista = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(json);
            lista.addAll(listaParser(jsonArray));
        } catch (JSONException e) {
            JSONObject jsonObject = new JSONObject(json);
            lista.add(specializareParser(jsonObject));
        }
        return lista;
    }
    private static List<Specializare> listaParser(JSONArray jsonArray) throws JSONException {
        List<Specializare> lista=new ArrayList<>();
        for(int i=0;i< jsonArray.length();i++){
            lista.add(specializareParser(jsonArray.getJSONObject(i)));
        }
        return lista;
    }
    private static Specializare specializareParser(JSONObject jsonObject) throws JSONException {
        String denumire= jsonObject.getString(DENUMIRE);
        String descriere= jsonObject.getString(DESCRIERE);
        Specializare specializare=new Specializare(denumire,descriere);
        return specializare;
    }
}

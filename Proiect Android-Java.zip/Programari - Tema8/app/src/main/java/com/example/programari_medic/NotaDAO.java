package com.example.programari_medic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.programari_medic.Nota;

import java.util.List;

@Dao
public interface NotaDAO {

    @Insert
    void insertNota(Nota nota);

    @Query("SELECT * FROM note")
    List<Nota> getAllNote();

    @Delete
    void deleteNota(Nota nota);
    @Update
    void updateNota(Nota nota);
}
package com.example.programari_medic;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Entity(  tableName = "clienti")
public  class Client implements Serializable {
    @PrimaryKey(autoGenerate = true)
    int idClient;

    String nume;
    String prenume;
    String telefon;
    String localitate;
    Date dataNasterii;
    @Ignore
    List<Programare> programari;

    public Client(String nume, Date dataNasterii, String localitate, String telefon, String prenume) {

        this.nume = nume;
        this.dataNasterii = dataNasterii;
        this.localitate = localitate;
        this.telefon = telefon;
        this.prenume = prenume;
    }

    public int getIdClient() {
        return idClient;
    }



    public String getNume() {
        return nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public String getTelefon() {
        return telefon;
    }

    public String getLocalitate() {
        return localitate;
    }

    public Date getDataNasterii() {
        return dataNasterii;
    }

    public int getNumarProgramari() {
        return programari.size();
    }

    public Programare getProgramare(int index) {
        return programari.get(index);
    }

    public void adaugaProgramare(Programare programare) {
        programari.add(programare);
    }

    public List<Programare> getProgramari() {
        return new ArrayList<>(programari);
    }

    public void setProgramari(List<Programare> programari) {
        this.programari = programari;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public void setLocalitate(String localitate) {
        this.localitate = localitate;
    }

    public void setDataNasterii(Date dataNasterii) {
        this.dataNasterii = dataNasterii;
    }



    @Override
    public String toString() {
        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
        return "Client Info:\n" +
                "  Nume: " + nume + "\n" +
                "  Prenume: " + prenume + "\n" +
                "  Telefon: " + telefon + "\n" +
                "  Localitate: " + localitate + "\n" +
                "  Data Nasterii: " + sdf.format(dataNasterii) + "\n";
    }
}

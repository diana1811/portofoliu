package com.example.programari_medic;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.List;

public class MedicAdapter extends ArrayAdapter<Medic> {
    private Context context;
    private List<Medic> medicList;
    private int layoutId;
    private LayoutInflater inflater;
    public MedicAdapter(@NonNull Context context, int resource, @NonNull List<Medic> objects, LayoutInflater inflater) {
        super(context, resource, objects);
        this.context=context;
        this.layoutId=resource;
        this.medicList=objects;
        this.inflater=inflater;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view=inflater.inflate(layoutId, parent,false);
        Medic medic=medicList.get(position);
        TextView tvViewMedicDen=view.findViewById(R.id.tvViewMedicDen);
        TextView tvViewMedicAn=view.findViewById(R.id.tvViewMedicAni);
        TextView tvViewMedicClinica=view.findViewById(R.id.tvViewMedicClinica);
        TextView tvViewMedicSp=view.findViewById(R.id.tvViewMedicSp);
        tvViewMedicDen.setText(medic.getNume());
        tvViewMedicAn.setText(String.valueOf(medic.getAniExperienta()));
        tvViewMedicClinica.setText(String.valueOf(medic.getIdClinica()));
        tvViewMedicSp.setText(String.valueOf(medic.getIdSpecializare()));
        if (medic.getAniExperienta() < 5) {
            tvViewMedicDen.setTextColor(Color.RED);
        } else {
            tvViewMedicDen.setTextColor(Color.GREEN);
        }
        return view;
    }
}

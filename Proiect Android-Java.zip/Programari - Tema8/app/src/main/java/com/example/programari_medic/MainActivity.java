package com.example.programari_medic;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnOk;
    EditText etTel;
    EditText etNume;
    EditText etPrenume;
//    Button btnNext;
    Button btnInreg;
    Button btnAdmin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        etTel=findViewById(R.id.etTel);
        btnOk=findViewById(R.id.btnOk);
        etNume=findViewById(R.id.etNume);
        etPrenume=findViewById((R.id.etPrenume));
//      btnNext=findViewById(R.id.btnNext);
        btnInreg=findViewById(R.id.btnInreg);
        btnAdmin=findViewById(R.id.btnAdmin);

        ProgramariDB dbInstance=ProgramariDB.getInstance(getApplicationContext());
        btnOk.setOnClickListener(view->{
            String tel = etTel.getText().toString();
            String nume = etNume.getText().toString();
            String prenume = etPrenume.getText().toString();

            Client client = dbInstance.getClientDAO().getClient(nume, prenume, tel);
            if (client != null) {
                Toast.makeText(this, "Utilizator găsit în baza de date: " + client.nume + " " + client.prenume, Toast.LENGTH_LONG).show();
                SharedPreferences sharedPreferences=getSharedPreferences("LOCAL", MODE_PRIVATE);
                SharedPreferences.Editor editor =sharedPreferences.edit();
                editor.putInt("token", client.getIdClient());
                editor.apply();
                Intent intent = new Intent(getApplicationContext(), AdaugaProgramareActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Utilizatorul nu există în baza de date.", Toast.LENGTH_LONG).show();
            }

        });

//        btnNext.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this, Pagina_meniu.class);
//                startActivity(intent);
//            }
//        });
        btnInreg.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Inregistrare.class);
            startActivity(intent);
        });

        btnAdmin.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Administrator.class);
            startActivity(intent);
        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0,1,1,"Adauga recenzie clinica");
        menu.add(0,2,2,"Adauga nota medic");
        menu.add(0,3,3,"Adauga sugestii aplicatie");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case 1:{
                Intent intent = new Intent(getApplicationContext(), AdaugaRecenzie.class);
                startActivity(intent);
                return true;
            }
            case 2:{
                Intent intent = new Intent(getApplicationContext(), AdaugaNota.class);
                startActivity(intent);
                return true;
            }
            case 3:{
                Intent intent = new Intent(getApplicationContext(), AdaugaSugestii.class);
                startActivity(intent);
                return true;
            }
        }
        return true;
    }
}
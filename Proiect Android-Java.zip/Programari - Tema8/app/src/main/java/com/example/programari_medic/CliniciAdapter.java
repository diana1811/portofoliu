package com.example.programari_medic;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.List;

public class CliniciAdapter extends ArrayAdapter<Clinica> {

    private Context context;
    private List<Clinica> clinicaList;
    private int layoutId;
    private LayoutInflater inflater;
    public CliniciAdapter(@NonNull Context context, int resource, @NonNull List<Clinica> objects, LayoutInflater inflater) {
        super(context, resource, objects);
        this.context=context;
        this.layoutId=resource;
        this.clinicaList=objects;
        this.inflater=inflater;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view=inflater.inflate(layoutId, parent,false);
        Clinica clinica=clinicaList.get(position);
        TextView tvViewClDen=view.findViewById(R.id.tvViewCDen);
        TextView tvViewClAn=view.findViewById(R.id.tvViewCAni);
        TextView tvViewClData=view.findViewById(R.id.tvViewCData);
        Spinner spViewClSp=view.findViewById(R.id.spViewCSp);
        tvViewClDen.setText(clinica.getDenumire());
        tvViewClAn.setText(String.valueOf(clinica.getAniExistenta()));
        tvViewClData.setText(new SimpleDateFormat("dd/MM/yyyy").format(clinica.getDataInfiintare()));

        if(clinica.getAniExistenta()>10){
            tvViewClAn.setTextColor(Color.GREEN);
        }
        return view;
    }
}

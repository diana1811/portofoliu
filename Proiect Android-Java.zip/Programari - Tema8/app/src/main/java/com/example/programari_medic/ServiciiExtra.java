package com.example.programari_medic;

public class ServiciiExtra {
    String id;
    String denumire;
    float pret;

    public ServiciiExtra() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    @Override
    public String toString() {
        return "Serviciul extra " + denumire + " are pretul de "+ pret;
    }
}

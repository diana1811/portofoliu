package com.example.programari_medic;

import java.io.Serializable;

public class ProdusMedical implements Serializable {
    private String id;
    private String denumireProdusMedical;
    private float pret;

    public ProdusMedical() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDenumire() {
        return denumireProdusMedical;
    }

    public void setDenumire(String denumire) {
        this.denumireProdusMedical = denumire;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    @Override
    public String toString() {
        return "Produsul medical " + denumireProdusMedical + " costa " + pret +
                " lei!";
    }
}
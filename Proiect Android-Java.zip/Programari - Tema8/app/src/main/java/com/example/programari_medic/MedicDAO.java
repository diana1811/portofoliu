package com.example.programari_medic;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.programari_medic.Medic;

import java.util.List;

@Dao
public interface MedicDAO {

    @Insert
    void insertMedic(Medic medic);

    @Query("SELECT * FROM medici")
    List<Medic> getAllMedici();

    @Delete
    void deleteMedici(Medic medic);
    @Query("DELETE FROM medici WHERE idMedic = :idMedic")
    void deleteMedicById(int idMedic);

    @Update
    void updateMedic(Medic medic);
    @Query("SELECT * FROM medici WHERE nume = :nume LIMIT 1")
    Specializare getMedicByNume(String nume);
}
package com.example.programari_medic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ServSiProduse extends AppCompatActivity {

    private EditText etDenumire;
    private EditText etPret;
    private Button btnGolireDate;
    private FloatingActionButton fabSave;
    private FloatingActionButton fabDelete;
    private ListView lvProduse;
    private List<ProdusMedical> produse = new ArrayList<>();
    private FirebaseService firebaseService;
    private int indexProdusSelectat = -1;
    Button btnInapoi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_serv_si_produse);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initComponente();
        firebaseService = FirebaseService.getInstance();
        firebaseService.addProduseListener(dataChangeCallback());
    }

    private Callback<List<ProdusMedical>> dataChangeCallback() {
        return rezultat -> {
            produse.clear();
            produse.addAll(rezultat);
            ArrayAdapter<ProdusMedical> adapter = (ArrayAdapter<ProdusMedical>) lvProduse.getAdapter();
            adapter.notifyDataSetChanged();
            golireText();
        };
    }

    private void initComponente() {
        etDenumire = findViewById(R.id.etDenumire);
        etPret = findViewById(R.id.etPret);
        btnGolireDate = findViewById(R.id.btnGolireDate);
        fabSave = findViewById(R.id.fabSave);
        fabDelete = findViewById(R.id.fabDelete);
        lvProduse = findViewById(R.id.lvProduse);
        ArrayAdapter<ProdusMedical> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, produse);
        lvProduse.setAdapter(adapter);
        btnGolireDate.setOnClickListener(golireDateEventListener());
        fabSave.setOnClickListener(saveEventListener());
        fabDelete.setOnClickListener(deleteEventListener());
        lvProduse.setOnItemClickListener(produsSelectatEventListener());
        btnInapoi=findViewById(R.id.btnInapoi);
        btnInapoi.setOnClickListener(view->{
            Intent intent = new Intent(getApplicationContext(), Administrator.class);
            startActivity(intent);
        });
    }

    private AdapterView.OnItemClickListener produsSelectatEventListener() {
        return (adapterView, view, position, param) -> {
            indexProdusSelectat = position;
            ProdusMedical produsMedical = produse.get(position);
            etDenumire.setText(produsMedical.getDenumire());
            etPret.setText(String.valueOf(produsMedical.getPret()));
        };
    }

    private View.OnClickListener deleteEventListener() {
        return view -> {
            if (indexProdusSelectat != -1) {
                firebaseService.delete(produse.get(indexProdusSelectat));
            }
        };
    }

    private View.OnClickListener saveEventListener() {
        return view -> {
            if (validare()) {
                if (indexProdusSelectat == -1) {
                    ProdusMedical produsMedical = actualizareProdusFromUI(null);
                    firebaseService.insert(produsMedical);
                } else {
                    ProdusMedical produsMedical = actualizareProdusFromUI(produse.get(indexProdusSelectat).getId());
                    firebaseService.update(produsMedical);
                }
            }

        };
    }

    private ProdusMedical actualizareProdusFromUI(String id) {
        ProdusMedical produsMedical = new ProdusMedical();
        produsMedical.setId(id);
        produsMedical.setDenumire(etDenumire.getText().toString());
        produsMedical.setPret(Float.valueOf(etPret.getText().toString()));
        return produsMedical;
    }

    private boolean validare() {
        if (etDenumire.getText() == null || etDenumire.getText().toString().isEmpty() || etPret.getText() == null || etPret.getText().toString().isEmpty()) {
            Toast.makeText(this, "Validarea nu a functionat", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private View.OnClickListener golireDateEventListener() {
        return view -> golireText();
    }

    private void golireText() {
        etDenumire.setText(null);
        etPret.setText(null);
        indexProdusSelectat = -1;
    }
}